package Pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ActiveAlertsPage extends HomePage {

	public ActiveAlertsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	/****
	 * Returns the Element to be clicked on Active Alert Table
	 * 
	 * @param value : Alert Name
	 ***/
	public WebElement SelectElementOnActiveAlertTable(String value) {
		//int i=121;
		return driver.findElement(By.xpath(
				"//div[@id='root_mashupcontainer-5_convergedhxgrid-121-bounding-box']//div[@class='objbox']//div[@cellValue='"+ value +"']"));
		
	}
		
	/**
	 * @return WebElement of start date calender on "Alert" tab
	 */
	public WebElement clickOnCalendar() throws InterruptedException {
		
		Thread.sleep(1000);
		WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178"));
		SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
		Thread.sleep(1000);
		WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#datetext"));
		SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
		Thread.sleep(1000);
		return last1.findElement(By.cssSelector("#input"));
	}
	
	/**
	 * @return WebElement of month on "Calender" tab
	 */
	public WebElement clickOnMonthDropdown() throws InterruptedException {
	
		Thread.sleep(1000);
		WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178-external-wc"));
		SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
		Thread.sleep(1000);
		WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#currmonth"));
		SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
		Thread.sleep(1000);
		return last1.findElement(By.cssSelector("#select"));
	}
	
	/**
	 * @return List<WebElement> list of items of month drop-down
	 */
	public List<WebElement> getListOfMonths() {
		
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(28)"));
		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return ListItems;
	}
	
	/**
	 * This method is to select option from month drop-down list
	 * 
	 * @param siteName : name of the month to be selected from the list
	 */
	//selecting the desired month
	public void selectDesiredMonth(String selectedMonth) throws InterruptedException {
		for (WebElement listRoot : getListOfMonths()) {
	// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");
	// If the list name matches the elements text, then click on the element
			if (ele.equals(selectedMonth)) {
				listRoot.click();
				break;
			}	
		}
	}
	/**
	 * @return WebElement of "Year"
	 */
	public WebElement clickOnYearDropdown() throws InterruptedException {
		
		Thread.sleep(1000);
		SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178-external-wc")).getShadowRoot();
		Thread.sleep(1000);
		SearchContext shadow1 = shadow0.findElement(By.cssSelector("#curryear")).getShadowRoot();
		Thread.sleep(1000);
		return shadow1.findElement(By.cssSelector("#select"));
	}

	//getting the list of months
	//This Element is inside single shadow DOM.
	public List<WebElement> getListOfYear() {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(29)"));
		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);

		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return ListItems;
	}

	/**
	 * This method is to select option from year drop-down list
	 * 
	 * @param siteName : name of the year to be selected from the list
	 */
	public void selectDesiredYear(String selectedYear) throws InterruptedException {
		for (WebElement listRoot : getListOfYear()) {
			// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");
			// If the list name matches the elements text, then click on the element
			if (ele.equals(selectedYear)) {
				listRoot.click();
				break;
	}	
	}
	}
	//select a date 
	public WebElement clickOnDateValue(String value) throws InterruptedException {
		int i=5;
		
		while (true) {
			try {
				Thread.sleep(1000);
				SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178-external-wc")).getShadowRoot();
				Thread.sleep(1000);
				WebElement tab = shadow.findElement(By.cssSelector(" div:nth-child(2) > div:nth-child(4) > div:nth-child(" + i + ")"));
				if(tab.getText().equals(value)) {
					tab.click();
				}	
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	

	//clicking on done button

	public WebElement clickOnDone() throws InterruptedException {
		//This Element is inside single shadow DOM.
			Thread.sleep(1000);
			SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178-external-wc")).getShadowRoot();
			Thread.sleep(1000);
			return shadow.findElement(By.cssSelector("ptcs-button[aria-label='Done']"));
			
		}
	//
	public WebElement CalenderValue() throws InterruptedException {
		SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178")).getShadowRoot();
		Thread.sleep(1000);
		SearchContext shadow1 = shadow0.findElement(By.cssSelector("#datetext")).getShadowRoot();
		Thread.sleep(1000);
		return shadow1.findElement(By.cssSelector("#input"));
	}
	
	public WebElement clickOnHour() throws InterruptedException{
		
		//This Element is inside 2 nested shadow DOM.	
		Thread.sleep(1000);
		SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178-external-wc")).getShadowRoot();
		Thread.sleep(1000);
		SearchContext shadow1 = shadow0.findElement(By.cssSelector("#currhour")).getShadowRoot();
		Thread.sleep(1000);
		return shadow1.findElement(By.cssSelector("#select"));
	}
	
	public WebElement clickOnMinute() throws InterruptedException{
		//This Element is inside 2 nested shadow DOM.
				
		SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-178-external-wc")).getShadowRoot();
		Thread.sleep(1000);
		SearchContext shadow1 = shadow0.findElement(By.cssSelector("#currminute")).getShadowRoot();
		Thread.sleep(1000);
		return shadow1.findElement(By.cssSelector("#select"));
	}
	
	public List<WebElement> getListOfHours() {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(29)"));
		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);

		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return ListItems;
		}

		//selecting the desired month
		public void selectDesiredHour(String selectedHour) throws InterruptedException {
			for (WebElement listRoot : getListOfHours()) {
		// Get the element from the list
				String ele = listRoot.getDomAttribute("aria-label");
		// If the list name matches the elements text, then click on the element
				if (ele.equals(selectedHour)) {
					listRoot.click();
					break;
				}	
			}
		}
		
		/**
		 * @return WebElement of End date calender on "Alert" tab
		 */
	public WebElement clickOnEndDateCalendar() throws InterruptedException {
		WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-180"));
		SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
		Thread.sleep(1000);
		WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#datetext"));
		SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
		Thread.sleep(1000);
		return last1.findElement(By.cssSelector("#input"));
	}

	/**
	 * @return WebElement of month on "calender" tab
	 */
	public WebElement clickOnMonthEndDropdown() throws InterruptedException {
		WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-180-external-wc"));
		SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
		Thread.sleep(1000);
		WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#currmonth"));
		SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
		Thread.sleep(1000);
		return last1.findElement(By.cssSelector("#select"));
	}

	/**
	 * @return List<WebElement> list of items of month drop-down
	 */
	public List<WebElement> getListOfEndMonths() {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(31)"));
		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return ListItems;
	}

	/**
	 * This method is to select option from month drop-down list
	 * 
	 * @param siteName : name of the month to be selected from the list
	 */
	public void selectDesiredEndMonth(String selectedMonth) throws InterruptedException {
		for (WebElement listRoot : getListOfEndMonths()) {
	// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");
	// If the list name matches the elements text, then click on the element
			if (ele.equals(selectedMonth)) {
				listRoot.click();
				break;
			}	
		}
	}
	
	
	/**
	 * @return WebElement of year.
	 */
	public WebElement clickOnEndYearDropdown() throws InterruptedException {
		SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-180-external-wc")).getShadowRoot();
		Thread.sleep(1000);
		SearchContext shadow1 = shadow0.findElement(By.cssSelector("#curryear")).getShadowRoot();
		Thread.sleep(1000);
		return shadow1.findElement(By.cssSelector("#select"));
		
	}

	//getting the list of months
	//This Element is inside single shadow DOM.
	public List<WebElement> getListOfEndYear() {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(32)"));
		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
	return ListItems;
	}

	/**
	 * This method is to select option from year drop-down list
	 * 
	 * @param siteName :  year to be selected from the list
	 */
	public void selectDesiredEndYear(String selectedYear) throws InterruptedException {
		for (WebElement listRoot1 : getListOfEndYear()) {
	// Get the element from the list
			String ele = listRoot1.getDomAttribute("aria-label");
	// If the list name matches the elements text, then click on the element
			if (ele.equals(selectedYear)) {
				listRoot1.click();
				break;
			}	
		}
	}
	
	public WebElement clickOnEndDateValue(String value) throws InterruptedException {
		int i=5;	
		while (true) {
			try {
				SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-180-external-wc")).getShadowRoot();
				Thread.sleep(1000);
				WebElement tab = shadow.findElement(By.cssSelector(" div:nth-child(2) > div:nth-child(4) > div:nth-child(" + i + ")"));
				if(tab.getText().equals(value)) {	
					tab.click();			
				}	
				i++;
			} catch (Exception e) {
				return null;
				}
			}		
	}
	
		//clicking on done button
		public WebElement clickOnEndDone() throws InterruptedException {
			SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-180-external-wc")).getShadowRoot();
			Thread.sleep(1000);
			return shadow.findElement(By.cssSelector("ptcs-button[aria-label='Done']"));
			
		}
	

}
