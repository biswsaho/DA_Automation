package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EditAlertConfigurationPage {
	WebDriver driver;

	public EditAlertConfigurationPage(WebDriver driver) {
		this.driver = driver;
	}

	/****
	 * Returns radio button for given value
	 * 
	 * @param value : option to select i.e. Family/MeasurmentPoint
	 ***/
	public WebElement optionSelectionOnEditAlertConfig(String value) {
		return driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//table//td[@state-name='"
						+ value + "']"));
	}

	// Return family drop-down on Edit AlertConfiguration page
	public final WebElement familyDropDownOnEditAlertConfig() throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElementFamilyDropdown = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-224']"));
		SearchContext lastFamilyDropdown = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropdown);
		WebElement family = lastFamilyDropdown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return family;
	}

	// Return property name drop-down on Edit AlertConfiguration page
	public final WebElement propertyDropDownOnEditAlertConfig() throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElementPropertyName = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-190']"));
		SearchContext lastPropertyName = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementPropertyName);
		WebElement property = lastPropertyName.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return property;
	}

	// Returns alert name drop-down on Edit AlertConfiguration page
	public final WebElement alertNameDropDownOnEditAlertConfig() throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElementAlertName = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-258']"));
		SearchContext lastAlertName = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertName);
		WebElement alert = lastAlertName.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return alert;
	}

	/**
	 * Locates the list shadow root and locates list of
	 *
	 * @return List<WebElement> list of items
	 */
	public List<WebElement> getListAlertElements() {
		WebElement shadowDomHostElementSiteValue = driver
				.findElement(By.cssSelector("body > ptcs-list[selected-value='LowTempDemoAlertOne']"));
		SearchContext listShadowRoot = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
		// WebElement listShadowRoot =
		// this.getShadowRoot(shadowDomHostElementSiteValue);
		List<WebElement> listItems = listShadowRoot.findElements(By.cssSelector(
				"div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return listItems;
	}

	/**
	 * This method is to select option from family drop-down list
	 * 
	 * @param alertName : name of the property to be selected from the list
	 */
	public void selectListAlertOptionByName(String alertName) {
		for (WebElement listRoot : getListAlertElements()) {
			// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");

			// If the list name matches the elements text, then click on the element
			if (ele.equals(alertName)) {
				listRoot.click();
				break;
			}
		}
	}

	// Returns radio button of Alert type on Edit AlertConfiguration
	public WebElement alertTypeSelectionOnEditAlertConfig(String value) {
		return driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//div[@id='root_mashupcontainer-5_radiobuttonlist-257']//table//td[@state-name='"
						+ value + "']"));
	}

	// Returns WebElement for alert value text field on Edit AlertConfiguration
	public final WebElement alertValueOnEditAlertConfig() throws InterruptedException {
		WebElement shadowDomHostElementAlertValue = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//ptcs-textarea[@id='root_mashupcontainer-5_ptcstextarea-259']"));
		SearchContext lastAlertValue = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertValue);
		lastAlertValue.findElement(By.cssSelector("textarea[part='text-value']")).clear();
		WebElement alertValue = lastAlertValue.findElement(By.cssSelector("textarea[part='text-value']"));
		return alertValue;
	}

	// Returns toggle for limit on Edit AlertConfiguration
	public final WebElement limitToggle() throws InterruptedException {
		WebElement shadowDomHostElementLimitInclusive = driver.findElement(By.cssSelector(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//ptcs-toggle-button[@id='root_mashupcontainer-5_ptcstogglebutton-260']"));
		WebElement lastAddLimitInclusive = (WebElement) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementLimitInclusive);
		WebElement limit = lastAddLimitInclusive.findElement(By.cssSelector("div[part='rectangle']"));
		return limit;
	}

	// Returns update button on Edit AlertConfiguration
	public final WebElement update() {
		return driver.findElement(By.xpath("//ptcs-button[@id='root_mashupcontainer-5_ptcsbutton-253']"));
	}

	public String check() throws InterruptedException {
		Thread.sleep(1000);
		String status = driver.findElement(By.xpath("//div[@id='status-msg-text']")).getText();
		return status;
	}
	
	// Returns alert name drop-down on Edit AlertConfiguration page
		public final WebElement alertNameDropDownOnEditWithMeasurementPoint() throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElementAlertName = driver.findElement(By.xpath(
		"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-213']"));
		SearchContext lastAlertName = (SearchContext) ((JavascriptExecutor) driver)
		.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertName);
		WebElement alert = lastAlertName.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return alert;
		}
		//Edit Measurement Point in Alert Config
		// Returns radio button of Alert type on Edit AlertConfiguration
		public WebElement alertTypeSelectionOnEditWithMeasurementPoint(String value) {
		return driver.findElement(By.xpath(
		"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//div[@id='root_mashupcontainer-5_radiobuttonlist-243']//table//td[@state-name='"
		+ value + "']"));
		}

		public final WebElement alertValueOnEditWithMeasurementPoint() throws InterruptedException {
			WebElement shadowDomHostElementAlertValue = driver.findElement(By.xpath(
			"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='2']//ptcs-textarea[@id='root_mashupcontainer-5_ptcstextarea-152']"));
			SearchContext lastAlertValue = (SearchContext) ((JavascriptExecutor) driver)
			.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertValue);
			lastAlertValue.findElement(By.cssSelector("textarea[part='text-value']")).clear();
			WebElement alertValue = lastAlertValue.findElement(By.cssSelector("textarea[part='text-value']"));
			return alertValue;
			}
}