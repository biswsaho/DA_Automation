package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	WebDriver driver;
	By by;
	WebElement we;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * Method to locate emailId input box
	 * 
	 * @return WebElement
	 */
	public final WebElement getEmailInputBox() {
		return driver.findElement(By.xpath("/html/body/div/div[4]/form/input[1]"));
	}

	/**
	 * Method to locate password input box
	 * 
	 * @return WebElement
	 */
	public final WebElement getPasswordInputBox() {
		return driver.findElement(By.xpath("/html/body/div/div[4]/form/input[2]"));
	}

	/**
	 * Method to locate login button
	 * 
	 * @return WebElement
	 */
	public final WebElement getLoginButton() {
		return driver.findElement(By.xpath("/html/body/div/div[4]/form/input[3]"));
	}

	// Error Element
	public final WebElement errorElement() {
		return driver.findElement(By.xpath("/html/body/div/div[4]/form/p"));
	}

	/**
	 * Method to locate emailId input box
	 * 
	 * @return WebElement
	 */
	public final WebElement getUser() {
		return driver.findElement(By.xpath("//ptcs-label[@id='root_ptcslabel-16']"));
	}
}