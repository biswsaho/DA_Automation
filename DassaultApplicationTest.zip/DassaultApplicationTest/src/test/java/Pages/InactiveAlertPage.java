package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class InactiveAlertPage extends HomePage {

	public InactiveAlertPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	//clicking on calendar table
	//This Element is inside 2 nested shadow DOM.
	public WebElement clickOnCalendar() throws InterruptedException {

	Thread.sleep(1000);
	WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-170"));
	SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
	Thread.sleep(1000);
	WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#datetext"));
	SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
	Thread.sleep(1000);
	return last1.findElement(By.cssSelector("#input"));
	}



	//clicking month dropdown
	//This Element is inside 2 nested shadow DOM.
	public WebElement clickOnMonthDropdown() throws InterruptedException {

	Thread.sleep(1000);
	WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-170-external-wc"));
	SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
	Thread.sleep(1000);
	WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#currmonth"));
	SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
	Thread.sleep(1000);
	return last1.findElement(By.cssSelector("#select"));
	}

	//getting the list of months
	//This Element is inside single shadow DOM.
	public List<WebElement> getListOfMonths() {
	WebElement shadowDomHostElement = driver.findElement(By.cssSelector("ptcs-list[selected-value='February']"));
	SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);



	List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
	return ListItems;
	}



	//selecting the desired month
	public void selectDesiredMonth(String selectedMonth) throws InterruptedException {
	for (WebElement listRoot : getListOfMonths()) {
	// Get the element from the list
	String ele = listRoot.getDomAttribute("aria-label");
	// If the list name matches the elements text, then click on the element
	if (ele.equals(selectedMonth)) {
	listRoot.click();
	break;
	}
	}
	}


	// for year
	public WebElement clickOnYearDropdown() throws InterruptedException {

	Thread.sleep(1000);
	SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-170-external-wc")).getShadowRoot();
	Thread.sleep(1000);
	SearchContext shadow1 = shadow0.findElement(By.cssSelector("#curryear")).getShadowRoot();
	Thread.sleep(1000);
	return shadow1.findElement(By.cssSelector("#select"));
	}



	//getting the list of months
	//This Element is inside single shadow DOM.
	public List<WebElement> getListOfYear() {
	WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(29)"));
	SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);



	List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
	return ListItems;
	}



	//selecting the desired month
	public void selectDesiredYear(String selectedYear) throws InterruptedException {
	for (WebElement listRoot : getListOfYear()) {
	// Get the element from the list
	String ele = listRoot.getDomAttribute("aria-label");
	// If the list name matches the elements text, then click on the element
	if (ele.equals(selectedYear)) {
	listRoot.click();
	break;
	}
	}
	}
	//select a date
	public WebElement clickOnDateValue(String value) throws InterruptedException {
	int i=5;

	while (true) {
	try {
	//This Element is inside single shadow DOM.
	Thread.sleep(1000);
	SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-170-external-wc")).getShadowRoot();
	Thread.sleep(1000);
	WebElement tab = shadow.findElement(By.cssSelector(" div:nth-child(2) > div:nth-child(4) > div:nth-child(" + i + ")"));
	if(tab.getText().equals(value)) {
	tab.click();
	}
	i++;
	} catch (Exception e) {
	return null;
	}
	}
	}
	//clicking on done button



	public WebElement clickOnDone() throws InterruptedException {
	//This Element is inside single shadow DOM.
	Thread.sleep(1000);
	SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-170-external-wc")).getShadowRoot();
	Thread.sleep(1000);
	return shadow.findElement(By.cssSelector("ptcs-button[aria-label='Done']"));

	}
	// End Date

	public WebElement clickOnEndDateCalendar() throws InterruptedException {

	Thread.sleep(1000);
	WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-172"));
	SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
	Thread.sleep(1000);
	WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#datetext"));
	SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
	Thread.sleep(1000);
	return last1.findElement(By.cssSelector("#input"));
	}



	//clicking month dropdown
	//This Element is inside 2 nested shadow DOM.
	public WebElement clickOnMonthEndDropdown() throws InterruptedException {

	Thread.sleep(1000);
	WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-172-external-wc"));
	SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
	Thread.sleep(1000);
	WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#currmonth"));
	SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
	Thread.sleep(1000);
	return last1.findElement(By.cssSelector("#select"));
	}



	//getting the list of months
	//This Element is inside single shadow DOM.
	public List<WebElement> getListOfEndMonths() {
	WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(31)"));
	SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);



	List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
	return ListItems;
	}



	//selecting the desired month
	public void selectDesiredEndMonth(String selectedMonth) throws InterruptedException {
	for (WebElement listRoot : getListOfEndMonths()) {
	// Get the element from the list
	String ele = listRoot.getDomAttribute("aria-label");
	// If the list name matches the elements text, then click on the element
	if (ele.equals(selectedMonth)) {
	listRoot.click();
	break;
	}
	}
	}


	// for End year
	public WebElement clickOnEndYearDropdown() throws InterruptedException {

	Thread.sleep(1000);
	SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-172-external-wc")).getShadowRoot();
	Thread.sleep(1000);
	SearchContext shadow1 = shadow0.findElement(By.cssSelector("#curryear")).getShadowRoot();
	Thread.sleep(1000);
	return shadow1.findElement(By.cssSelector("#select"));

	}



	//getting the list of months
	//This Element is inside single shadow DOM.
	public List<WebElement> getListOfEndYear() {
	WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(32)"));
	SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
	List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
	return ListItems;
	}



	//selecting the desired month
	public void selectDesiredEndYear(String selectedYear) throws InterruptedException {
	for (WebElement listRoot1 : getListOfEndYear()) {
	// Get the element from the list
	String ele = listRoot1.getDomAttribute("aria-label");
	// If the list name matches the elements text, then click on the element
	if (ele.equals(selectedYear)) {
	listRoot1.click();
	break;
	}
	}
	}
	public WebElement clickOnEndDateValue(String value) throws InterruptedException {
	int i=5;
	while (true) {
	try {
	//This Element is inside single shadow DOM.
	Thread.sleep(1000);
	SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-172-external-wc")).getShadowRoot();
	Thread.sleep(1000);
	WebElement tab = shadow.findElement(By.cssSelector(" div:nth-child(2) > div:nth-child(4) > div:nth-child(" + i + ")"));
	if(tab.getText().equals(value)) {

	tab.click();
	}
	i++;
	} catch (Exception e) {
	return null;
	}
	}
	}

	//clicking on done button
	public WebElement clickOnEndDone() throws InterruptedException {
	//This Element is inside single shadow DOM.
	Thread.sleep(1000);
	SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-172-external-wc")).getShadowRoot();
	Thread.sleep(1000);
	return shadow.findElement(By.cssSelector("ptcs-button[aria-label='Done']"));

	}
	
	/**
	 * @return WebElement of option to be selected on "Inactive" tab
	 * 
	 **/
	public final WebElement familyDropDownOnAddAlertConfig() throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElementFamilyDropDown = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='1']//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-235']"));
		SearchContext lastFamilyDropDown = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDown);
		// WebElement lastFamilyDropDown = (WebElement) ((JavascriptExecutor) driver)
		// .executeScript("return arguments[0].shadowRoot",
		// shadowDomHostElementFamilyDropDown);
		WebElement family = lastFamilyDropDown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return family;
	}

	/**
	 * Locates the list shadow root and locates list of
	 *
	 * @return List<WebElement> list of items
	 */
	public List<WebElement> getListFamilyElements() {
		WebElement shadowDomHostElementSiteValue = driver
				.findElement(By.cssSelector("body > ptcs-list[selected-value='Family1']"));
		SearchContext listShadowRoot = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
		// WebElement listShadowRoot =
		// this.getShadowRoot(shadowDomHostElementSiteValue);
		List<WebElement> listItems = listShadowRoot.findElements(By.cssSelector(
				"div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return listItems;
	}
	
	public WebElement SelectElementOninactiveAlertTable(String value) {
		return driver.findElement(By.xpath(
		"//div[@id='root_mashupcontainer-5_convergedhxgrid-120-dhxgrid']//div[@class='objbox']//div[@cellValue='+ value +']"));

		}
}
