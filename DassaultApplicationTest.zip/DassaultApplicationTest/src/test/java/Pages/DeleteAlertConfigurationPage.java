package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DeleteAlertConfigurationPage {
	WebDriver driver;

	public DeleteAlertConfigurationPage(WebDriver driver) {
		this.driver = driver;
	}

	/****
	 * Returns radio button for given value
	 * 
	 * @param value : option to select i.e. Family/MeasurmentPoint
	 ***/
	public WebElement optionSelectionOnDeleteAlertConfig(String value) {
		return driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='3']//table//td[@state-name='"
						+ value + "']"));
	}

	// This is to locate the family dropdown on "Delete" tab
	public final WebElement FamilyDropdown() throws InterruptedException {
		WebElement shadowDomHostElementFamilyDropDown = driver.findElement(By.cssSelector(
				"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(1)"));
		SearchContext lastFamilyDropDown = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDown);
		WebElement family = lastFamilyDropDown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return family;
	}

	// This is to locate the PropertyName dropdown on "Delete" tab
	public final WebElement PropertyName() throws InterruptedException {
		Thread.sleep(100);
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector(
				"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(6) > ptcs-dropdown:nth-child(1)"));
		SearchContext last = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		Thread.sleep(100);
		WebElement propertyName = last.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return propertyName;
	}

	// This is to locate the delete button
	public final WebElement DeleteButton() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-304"));
	}

	public String check() throws InterruptedException {
		Thread.sleep(1000);
		String status = driver.findElement(By.xpath("//div[@id='status-msg-text']")).getText();
		return status;
	}
}