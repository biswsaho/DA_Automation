package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import base.TestBase;

public class HomePage extends TestBase {
	static WebDriver driver;

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	/************************* ENUM ON HOME PAGE START *************************/

	// Enum for options in the site drop down list
	public enum SITE_OPTIONS {
		Site01;

		public String getName() {
			return this.name().replace("_", " ");
		}
	}

	// Enum for options in the building drop down list
	public enum BUILDING_OPTIONS {
		Building01S01;

		public String getName() {
			return this.name().replace("_", " ");
		}
	}

	// Enum for tab name on home page
	public enum TAB_OPTIONS {
		AlertConfiguration("Alert Configuration");

		private final String value;

		TAB_OPTIONS(final String newValue) {
			value = newValue;
		}

		public String getValue() {
			return value;
		}

		public String getName() {
			return this.name().replace("_", " ");
		}
	}

	// Enum for sub tab name
	public enum SUB_TAB_OPTIONS {
		Add, Delete, Edit;

		public String getName() {
			return this.name().replace("_", " ");
		}
	}

	// Enum for family drop-down list options
	public enum FAMILY {
		Family1, Family2;

		public String getName() {
			return this.name().replace("_", " ");
		}
	}

	// Enum for property drop-down list options
	public enum PROPERTY {
		Battery;

		public String getName() {
			return this.name().replace("_", " ");
		}
	}

	/************************* ENUM ON HOME PAGE END *************************/

	/***
	 * This method is use to select the tab
	 * 
	 * @value : value send to the tab name
	 * 
	 ***/
	public WebElement selectTab(String value) {
		int i = 1;
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElementAlertConfiguration1 = driver.findElement(By.cssSelector(
						"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1)"));
				SearchContext lastAlertConfiguration1 = (SearchContext) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertConfiguration1);
				WebElement shadowDomHostElementAlertConfiguration2 = lastAlertConfiguration1.findElement(By.cssSelector(
						" ptcs-tabs:nth-child(2) > ptcs-tab:nth-child(" + i + ") > ptcs-label:nth-child(1)"));
				SearchContext lastAlertConfiguration2 = (SearchContext) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertConfiguration2);
				WebElement tab = lastAlertConfiguration2.findElement(By.cssSelector("div[part='label']"));
				if (tab.getText().equals(value)) {
					return tab;
				}
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}

	/***
	 * This method is use to select the sub tab
	 * 
	 * @value : value send to the tab name
	 * 
	 ***/
	public final WebElement selectSubTab(String value) {
		int i = 1;
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector(
						"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1)"));
				SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
				WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector(
						" ptcs-tabs:nth-child(2) > ptcs-tab:nth-child(" + i + ") > ptcs-label:nth-child(1)"));
				SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
				WebElement subTab = last1.findElement(By.cssSelector("div[part='label']"));

				if (subTab.getText().equals(value)) {
					return subTab;
				}
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}

	// This is to return the status message
	public String statusMessage() {
		return driver.findElement(By.xpath("//div[@class='tw-status-msg-box']//div[@id='status-msg-text']")).getText();
	}

	// Delete family table
	public final WebElement deleteTableElement(String value) {
		List<WebElement> tableList = driver.findElements(By.xpath(
				"//*[@id=\"root_mashupcontainer-5_convergedhxgrid-308-dhxgrid\"]//div[@class=\"objbox\"]//child::table//tr//td[1]"));

		for (int i = 1; i < tableList.size(); i++) {
			if (tableList.get(i).getText().equals(value)) {
				return tableList.get(i);
			}
		}
		return null;
	}
}