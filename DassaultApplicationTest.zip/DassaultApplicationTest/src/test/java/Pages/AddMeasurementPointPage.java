package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddMeasurementPointPage extends HomePage{
	public AddMeasurementPointPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}	
	
	/**
	 * @return WebElement of Stream id drop-down 
	 */
	
	public final WebElement getStreamIDDropDown() throws InterruptedException {
		WebElement shadowDomHostElementSite = driver
				.findElement(By.xpath("//ptcs-dropdown[@id='#root_mashupcontainer-5_ptcsdropdown-188']"));
		SearchContext lastSite = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSite);
		// WebElement lastSite = this.getShadowRoot(shadowDomHostElementSite);
		return lastSite.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
	}
	
	/**
	 * @return WebElement of Family drop-down on "Add/Delete MeasurementPoint" tab
	 */	
	public final WebElement familyDropDowninMP() throws InterruptedException {
		WebElement shadowDomHostElementFamilyDropDown = driver.
				findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdropdown-200"));
		SearchContext lastFamilyDropDown = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDown);
		WebElement family= lastFamilyDropDown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return family;
	}

	/**
	 * @return List<WebElement> list of items of Family drop-down
	 */
	public List<WebElement> getfamilyDropDowninMP() {
		//shadow host
		WebElement shadowDomHostElementFamilyDropDownValue = driver.
				findElement(By.cssSelector("body > ptcs-list:nth-child(26)"));
		SearchContext lastFamilyDropDownValue = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDownValue);
		List<WebElement> familyValue = lastFamilyDropDownValue.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return familyValue;
	}

	/**
	 * This method is to select option from Family drop-down list
	 * 
	 * @param FamilyName : name of the Family to be selected from the list
	 */
	public  void selectFamilyDropdownListinMP(String FamilyName) {
	
		for(WebElement option3 : getfamilyDropDowninMP()){
		
            String value3=option3.getDomAttribute("aria-label");

	        if(value3.equals(FamilyName)) {
	            option3.click();
	            break;
	            
	        }
	        
	    }
		
	}

	//Returns WebElement of Measurement Point textfield
	public final WebElement measurementPoint() throws InterruptedException {
		WebElement shadowDomHostElementMPName = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='4']//ptcs-textfield[@id='root_mashupcontainer-5_ptcstextfield-141']"));	
		return shadowDomHostElementMPName;
	}
	
	// Returns WebElement of add button on "Add" tab
	public final WebElement add() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-142"));
		
	}
	public WebElement selectMeasurementPointFromTable(String value) {
		return driver.findElement(By.xpath(
		"//div[@id='root_mashupcontainer-5_convergedhxgrid-78-dhxgrid']//div[@class='objbox']//div[@cellValue='"+ value +"']" ));
		}
}

