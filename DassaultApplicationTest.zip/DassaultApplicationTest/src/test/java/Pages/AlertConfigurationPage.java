package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AlertConfigurationPage extends HomePage {

	public AlertConfigurationPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return WebElement of site drop-down on "Add" tab
	 */
	public final WebElement getSiteDropDown() throws InterruptedException {
		WebElement shadowDomHostElementSite = driver
				.findElement(By.xpath("//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-7']"));
		SearchContext lastSite = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSite);
		// WebElement lastSite = this.getShadowRoot(shadowDomHostElementSite);
		return lastSite.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
	}

	/**
	 * @return List<WebElement> list of items of site drop-down
	 */
	public List<WebElement> getListSiteElements() {
		WebElement shadowDomHostElementSiteValue = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(24)"));
		SearchContext listShadowRoot = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
		// WebElement listShadowRoot =
		// this.getShadowRoot(shadowDomHostElementSiteValue);
		List<WebElement> listItems = listShadowRoot.findElements(By.cssSelector(
				"div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return listItems;
	}

	/**
	 * This method is to select option from site drop-down list
	 * 
	 * @param siteName : name of the site to be selected from the list
	 */
	public void selectListSiteOptionByName(String siteName) {
		for (WebElement listRoot : getListSiteElements()) {
			// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");

			// If the list name matches the elements text, then click on the element
			if (ele.equals(siteName)) {
				listRoot.click();
				break;
			}
		}
	}

	/**
	 * @return WebElement of building drop-down on "Add" tab
	 */
	public final WebElement getBuildingDropDown() throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElementBuilding = driver
				.findElement(By.xpath("//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-16']"));
		SearchContext lastBuilding = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementBuilding);
		// WebElement lastBuilding = (WebElement) ((JavascriptExecutor) driver)
		// .executeScript("return arguments[0].shadowRoot",
		// shadowDomHostElementBuilding);
		return lastBuilding.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
	}

	/**
	 * @return List<WebElement> list of items from building drop-down
	 */
	public List<WebElement> getListBuildingElements() {
		WebElement shadowDomHostElementSiteValue = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(25)"));
		SearchContext listShadowRoot = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
		// WebElement listShadowRoot =
		// this.getShadowRoot(shadowDomHostElementSiteValue);
		List<WebElement> listItems = listShadowRoot.findElements(By.cssSelector(
				"div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return listItems;
	}

	/**
	 * This method is to select option from building drop-down list
	 * 
	 * @param buildingName : name of the building to be selected from the list
	 */
	public void selectListBuildingOptionByName(String buildingName) {
		for (WebElement listRoot : getListBuildingElements()) {
			// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");

			// If the list name matches the elements text, then click on the element
			if (ele.equals(buildingName)) {
				listRoot.click();
				break;
			}
		}
	}

	/**
	 * @return WebElement of option to be selected on "Add" tab
	 * 
	 * @param value : name of the option to be selected e.g. Family/MeaserPoint
	 */
	public WebElement optionSelectionOnAddAlertConfig(String value) {
		return driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='1']//table//td[@state-name='"
						+ value + "']"));
	}

	/**
	 * @return WebElement of family drop-down on "Add" tab
	 */
	public final WebElement familyDropDownOnAddAlertConfig() throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElementFamilyDropDown = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='1']//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-235']"));
		SearchContext lastFamilyDropDown = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDown);
		// WebElement lastFamilyDropDown = (WebElement) ((JavascriptExecutor) driver)
		// .executeScript("return arguments[0].shadowRoot",
		// shadowDomHostElementFamilyDropDown);
		WebElement family = lastFamilyDropDown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return family;
	}

	/**
	 * Locates the list shadow root and locates list of
	 *
	 * @return List<WebElement> list of items
	 */
	public List<WebElement> getListFamilyElements() {
		WebElement shadowDomHostElementSiteValue = driver
				.findElement(By.cssSelector("body > ptcs-list[selected-value='Family1']"));
		SearchContext listShadowRoot = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
		// WebElement listShadowRoot =
		// this.getShadowRoot(shadowDomHostElementSiteValue);
		List<WebElement> listItems = listShadowRoot.findElements(By.cssSelector(
				"div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return listItems;
	}

	/**
	 * This method is to select option from family drop-down list
	 * 
	 * @param familyName : name of the family to be selected from the list
	 */
	public void selectListFamilyOptionByName(String familyName) {
		for (WebElement listRoot : getListFamilyElements()) {
			// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");

			// If the list name matches the elements text, then click on the element
			if (ele.equals(familyName)) {
				listRoot.click();
				break;
			}
		}
	}

	/**
	 * @return WebElement of Property drop-down on "Add" tab
	 */
	public final WebElement propertyDropDownOnAddAlertConfig() throws InterruptedException {
		// Property Name
		WebElement shadowDomHostElementPropertyName = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='1']//ptcs-dropdown[@id='root_mashupcontainer-5_ptcsdropdown-239']"));
		SearchContext lastPropertyName = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementPropertyName);
		WebElement property = lastPropertyName.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return property;
	}

	/**
	 * Locates the list shadow root and locates list of
	 *
	 * @return List<WebElement> list of items
	 */
	public List<WebElement> getListPropertyElements() {
		WebElement shadowDomHostElementSiteValue = driver
				.findElement(By.cssSelector("body > ptcs-list[selected-value='Battery']"));
		SearchContext listShadowRoot = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
		// WebElement listShadowRoot =
		// this.getShadowRoot(shadowDomHostElementSiteValue);
		List<WebElement> listItems = listShadowRoot.findElements(By.cssSelector(
				"div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
		return listItems;
	}

	/**
	 * This method is to select option from family drop-down list
	 * 
	 * @param propertyName : name of the family to be selected from the list
	 */
	public void selectListPropertyOptionByName(String propertyName) {
		for (WebElement listRoot : getListPropertyElements()) {
			// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");

			// If the list name matches the elements text, then click on the element
			if (ele.equals(propertyName)) {
				listRoot.click();
				break;
			}
		}
	}

	// Returns WebElement of Alert Name
	public final WebElement alertName() throws InterruptedException {
		WebElement shadowDomHostElementAlertName = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='1']//ptcs-textarea[@id='root_mashupcontainer-5_ptcstextarea-250']"));
		SearchContext lastAlertName = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertName);
		WebElement alert = lastAlertName.findElement(By.cssSelector("textarea[part='text-value']"));
		return alert;
	}

	// Returns radio button of Alert type on Edit AlertConfiguration
	public WebElement alertTypeSelectionOnAddAlertConfig(String value) {
		return driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='1']//div[@id='root_mashupcontainer-5_radiobuttonlist-215']//table//td[@state-name='"
						+ value + "']"));
	}

	// Returns WebElement of Alert Value
	public final WebElement alertValueOnAddAlertConfig() throws InterruptedException {
		WebElement shadowDomHostElementAlertValue = driver.findElement(By.xpath(
				"//ptcs-mb-container [@sub-widget='2']//ptcs-mb-container[@sub-widget='1']//ptcs-textarea[@id='root_mashupcontainer-5_ptcstextarea-245']"));
		SearchContext lastAlertValue = (SearchContext) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertValue);
		lastAlertValue.findElement(By.cssSelector("textarea[part='text-value']")).clear();
		WebElement alertValue = lastAlertValue.findElement(By.cssSelector("textarea[part='text-value']"));
		return alertValue;
	}

	// Returns WebElement of add button on "Add" tab
	public final WebElement add() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-263"));
	}
}