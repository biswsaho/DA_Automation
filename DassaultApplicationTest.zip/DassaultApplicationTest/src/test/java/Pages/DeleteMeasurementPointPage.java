package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DeleteMeasurementPointPage {
	WebDriver driver;
	
	public DeleteMeasurementPointPage(WebDriver driver) {
		this.driver = driver;
	}
	// This is to locate the remove button
	public final WebElement DeleteButton() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-64"));
	}
		
		public String check() throws InterruptedException {
			Thread.sleep(1000);
			String status = driver.findElement(By.xpath("//div[@id='status-msg-text']")).getText();
			return status;
		}
		
		
}
