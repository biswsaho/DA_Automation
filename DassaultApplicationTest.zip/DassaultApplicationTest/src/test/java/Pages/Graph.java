package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Graph extends HomePage {
	public Graph(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	//clicking on calendar table
	//This Element is inside 2 nested shadow DOM.
	public WebElement clickOnCalendar() throws InterruptedException {
	
	Thread.sleep(1000);
	WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-185"));
	SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
	Thread.sleep(1000);
	WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#datetext"));
	SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
	Thread.sleep(1000);
	return last1.findElement(By.cssSelector("#input"));
	
	
	}
	
	
	//clicking month dropdown
	//This Element is inside 2 nested shadow DOM.
	public WebElement clickOnMonthDropdown() throws InterruptedException {
	Thread.sleep(1000);
	WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-185-external-wc"));
	SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
	Thread.sleep(1000);
	WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#currmonth"));
	SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
	Thread.sleep(1000);
	return last1.findElement(By.cssSelector("#select"));
	}
	
	
	
	//getting the list of months
	//This Element is inside single shadow DOM.
	public List<WebElement> getListOfMonths()  {
	WebElement shadowDomHostElement = driver.findElement(By.cssSelector("ptcs-list[selected-value='March']"));
	SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
	
	List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
	return ListItems;
	}
	
	//selecting the desired month
	public void selectDesiredMonth(String selectedMonth) throws InterruptedException {
		for (WebElement listRoot : getListOfMonths()) {
			// Get the element from the list
			String ele = listRoot.getDomAttribute("aria-label");

			// If the list name matches the elements text, then click on the element
			if (ele.equals(selectedMonth)) {
				listRoot.click();
				break;
			}
		}
	}

	public WebElement clickOnStartDateValue(String value) throws InterruptedException {
		int i=5;
		while (true) {
		try {
		//This Element is inside single shadow DOM.
		Thread.sleep(1000);
		SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-185-external-wc")).getShadowRoot();
		Thread.sleep(1000);
		WebElement tab = shadow.findElement(By.cssSelector(" div:nth-child(2) > div:nth-child(4) > div:nth-child(" + i + ")"));
		if(tab.getText().equals(value)) {

		tab.click();
		}
		i++;
		} catch (Exception e) {
		return null;
		}
		}



		}
	//clicking on year dropdown
	
	
		public WebElement clickOnYearDropdown() throws InterruptedException {
		
			Thread.sleep(1000);
			WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-185-external-wc"));
			SearchContext last0 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
			Thread.sleep(1000);
			WebElement shadowDomHostElement1 = last0.findElement(By.cssSelector("#curryear"));
			SearchContext last1 = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
			Thread.sleep(1000);
			return last1.findElement(By.cssSelector("#select"));
		
	}
     //getting the year dropdown
    public List<WebElement> listOfYear() {
    	 WebElement shadowDomHostElement = driver.findElement(By.cssSelector("ptcs-list[selected-value='2022']"));
    		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
    		
    		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
    		return ListItems;
    	 
    	 
     }
      
     //selecting the Year
     public void selectYear(String year) {
    	 for (WebElement listRoot : listOfEndYear()) {
  			// Get the element from the list
  			String ele = listRoot.getText();
  			// If the list name matches the elements text, then click on the element
  			if (ele.equals(year)) {
  				listRoot.click();
  				break;
  			}
  		}
    	 
     }
     
     //checking the status message
     public String check() throws InterruptedException {
 		Thread.sleep(1000);
 		String status = driver.findElement(By.xpath("//div[@id='status-msg-text']")).getText();
 	    System.out.println(status);
 		return status;
     }
     
     //Clicking on dismiss button
     public WebElement dismiss() throws InterruptedException {
  		Thread.sleep(1000);
  		return  driver.findElement(By.xpath(" //span[@class='close-sticky-btn']"));
  	  
  		
     }
     
     //clicking on done button
     public WebElement clickOnDone() throws InterruptedException {
    	//This Element is inside single shadow DOM.
    	 
    	 Thread.sleep(1000);
    	 WebElement shadowDomHostElement = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-185-external-wc"));
    	 SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
    	 Thread.sleep(1000);
    	 return last.findElement(By.cssSelector("ptcs-button[aria-label='Done']"));
     }
     
     //click on end date
     public WebElement clickOnEndDate() throws InterruptedException {
    	//This Element is inside 2 nested shadow DOM.
    	WebElement datebox=driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-187"));
    	return datebox;
     }
     
     //clicking on month dropdown
     public WebElement clickOnEndMonthDropdown() throws InterruptedException {
    	//This Element is inside 2 nested shadow DOM.
    	
    	 Thread.sleep(1000);
    	 SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-187-external-wc")).getShadowRoot();
    	 Thread.sleep(1000);
    	 SearchContext shadow1 = shadow0.findElement(By.cssSelector("#currmonth")).getShadowRoot();
    	 Thread.sleep(1000);
    	  return shadow1.findElement(By.cssSelector("ptcs-list-item[aria-label='March']"));
     }
     
     //getting the list of months
     public List<WebElement> getListOfEndMonths()  {
    		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("ptcs-list[selected-value='March']"));
    		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
    		
    		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
    		return ListItems;
     }
     
     public void selectDesiredEndMonth(String selectedMonth) throws InterruptedException {
 		for (WebElement listRoot : getListOfEndMonths()) {
 			// Get the element from the list
 			String ele = listRoot.getDomAttribute("aria-label");

 			// If the list name matches the elements text, then click on the element
 			if (ele.equals(selectedMonth)) {
 				listRoot.click();
 				break;
 			}
 		}
 	}
     
     //clicking on the year box
     public WebElement clickOnEndYearDropdown() throws InterruptedException {
    	//This Element is inside 2 nested shadow DOM.
    	 Thread.sleep(1000);
    	 SearchContext shadow0 = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-187-external-wc")).getShadowRoot();
    	 Thread.sleep(1000);
    	 SearchContext shadow1 = shadow0.findElement(By.cssSelector("#curryear")).getShadowRoot();
    	 Thread.sleep(1000);
    	 return shadow1.findElement(By.cssSelector("ptcs-list-item[aria-label='2022']"));
     }
     
     //getting the list of year
     public List<WebElement> listOfEndYear() {
    	 WebElement shadowDomHostElement = driver.findElement(By.cssSelector("ptcs-list[selected-value='2022']"));
 		SearchContext last = (SearchContext) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
 		
 		List<WebElement>ListItems=last.findElements(By.cssSelector("div[part='list-container'] > ptcs-v-scroller[part='list-items-container'] > div > div > ptcs-list-item[part='list-item']"));
 		return ListItems;
     }
     
     public void selectEndYear(String year) {
    	 for (WebElement listRoot : listOfEndYear()) {
  			// Get the element from the list
  			String ele = listRoot.getText();
  			System.out.println(ele);

  			// If the list name matches the elements text, then click on the element
  			if (ele.equals(year)) {
  				listRoot.click();
  				break;
  			}
  		}
    	 
     }
     
     public WebElement clickOnEndDateValue(String value) throws InterruptedException {
    	 int i=5;
    	 while (true) {
    	 try {
    	 //This Element is inside single shadow DOM.
    	 Thread.sleep(1000);
    	 SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-187-external-wc")).getShadowRoot();
    	 Thread.sleep(1000);
    	 WebElement tab = shadow.findElement(By.cssSelector(" div:nth-child(2) > div:nth-child(4) > div:nth-child(" + i + ")"));
    	 
    	 if(tab.getText().equals(value)) {

    	 tab.click();
    	 }
    	 i++;
    	 } catch (Exception e) {
    	 return null;
    	 }
    	 }
    	 }
     
     //click on done button
     public WebElement clickOnDoneToDate() throws InterruptedException {
     	//This Element is inside single shadow DOM.
     	 
    	//This Element is inside single shadow DOM.
    	 Thread.sleep(1000);
    	 SearchContext shadow = driver.findElement(By.cssSelector("#root_mashupcontainer-5_ptcsdatepicker-187-external-wc")).getShadowRoot();
    	 Thread.sleep(1000);
    	 return shadow.findElement(By.cssSelector("ptcs-button[aria-label='Done']"));
      }
     
   
	 
       	
	
}

