package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import common.ComposerPageFactory;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {
	public static Properties prop;
	public static Properties testProp;
	public static WebDriver driver;
	public static String descriptive;
	public static By by;
	public static WebElement we;
	public ComposerPageFactory composerPageFactory;
	private ComposerPageFactory[] composerPageFactoryNewSession;

	public TestBase() {
		try {
			prop = new Properties();
			FileInputStream fs = new FileInputStream(
					"C:\\Users\\AKPEDNEK\\Desktop\\DassaultApplicationTest\\src\\test\\resources\\PropertiesValue");
			prop.load(fs);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ComposerPageFactory getComposerPagesNewSession(int sessionCount) {
		return composerPageFactoryNewSession[sessionCount];
	}

	public ComposerPageFactory getComposerPages() {
		return composerPageFactory = new ComposerPageFactory(driver);
	}

	public static void changeDescriptiveTrue() {
		descriptive = "true";
	}

	public static void changeDescriptiveFalse() {
		descriptive = "false";
	}

	public static void initialization() {
		new TestBase();
		String browser = prop.getProperty("browser");

		// Launch the browser
		if (browser.contains("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\AKPEDNEK\\Desktop\\DassaultApplicationTest\\Drivers\\ChromeDriver\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.contains("ff")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}

		// Maximize the window
		driver.manage().window().maximize();

		// Delete all cookies
		driver.manage().deleteAllCookies();

		// Open the URL
		driver.get(prop.getProperty("url"));
	}

	public static void tearDown() {
		driver.close();
	}
}