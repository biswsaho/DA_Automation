package test;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class EditAlertConfigurationTest extends TestBase {
	private final String alertName = "LowTempDemoAlertOne";

	private final String alertValue = "40";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void editAlertConfigurationTest() throws InterruptedException, IOException {

		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(6000);

		// Click on site dropdown list and select value "Site01"
		wait.until(ExpectedConditions.visibilityOf(getComposerPages().alertConfigurationPage().getSiteDropDown()));
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		Thread.sleep(600);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());

		// Click on building dropdown list and select value "Building01S01"
		wait.until(ExpectedConditions.visibilityOf(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(600);
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());

		// Click on Alert Configuration tab
		getComposerPages().homePage().selectTab(TAB_OPTIONS.AlertConfiguration.getValue()).click();

		// Click on Add tab under "Alert Configuration"
		getComposerPages().homePage().selectSubTab(SUB_TAB_OPTIONS.Edit.getName()).click();

		// Select option Family
		getComposerPages().editAlertConfigurationPage().optionSelectionOnEditAlertConfig("Family").click();

		// Click on family drop down list and select "Family2"
		wait.until(ExpectedConditions.elementToBeClickable(
				getComposerPages().editAlertConfigurationPage().familyDropDownOnEditAlertConfig()));
		getComposerPages().editAlertConfigurationPage().familyDropDownOnEditAlertConfig().click();
		Thread.sleep(800);
		getComposerPages().alertConfigurationPage().selectListFamilyOptionByName(FAMILY.Family2.getName());

		// Click on property drop down list and select "Battery"
		wait.until(ExpectedConditions.elementToBeClickable(
				getComposerPages().editAlertConfigurationPage().propertyDropDownOnEditAlertConfig()));
		getComposerPages().editAlertConfigurationPage().propertyDropDownOnEditAlertConfig().click();
		Thread.sleep(800);
		getComposerPages().alertConfigurationPage().selectListPropertyOptionByName(PROPERTY.Battery.getName());

		// Select Alert name
		wait.until(ExpectedConditions.elementToBeClickable(
				getComposerPages().editAlertConfigurationPage().alertNameDropDownOnEditAlertConfig()));
		getComposerPages().editAlertConfigurationPage().alertNameDropDownOnEditAlertConfig().click();
		getComposerPages().editAlertConfigurationPage().selectListAlertOptionByName(alertName);

		// Alert Type
		getComposerPages().editAlertConfigurationPage().alertTypeSelectionOnEditAlertConfig("Above").click();

		// Enter Alert Value
		getComposerPages().editAlertConfigurationPage().alertValueOnEditAlertConfig().sendKeys(alertValue);

		// Alert Add Button
		Thread.sleep(1000);
		getComposerPages().editAlertConfigurationPage().update().click();

		// Check whether test failed or passed
		if (getComposerPages().editAlertConfigurationPage().check()
				.equals("Alert configuration updated successfully for family.")) {
			Assert.assertEquals("Alert configuration updated successfully for family.",
					getComposerPages().editAlertConfigurationPage().check());
		}
	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}
}