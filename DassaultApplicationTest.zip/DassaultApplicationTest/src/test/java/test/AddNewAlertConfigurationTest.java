package test;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class AddNewAlertConfigurationTest extends TestBase {

	private final String alertName = "LowTempDemoAlertOne";

	private final String alertValue = "20";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void addNewAlertConfigurationTest() throws InterruptedException, IOException {
		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(6000);

		// Click on site dropdown list and select value "Site01"
		wait.until(
				ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getSiteDropDown()));
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		Thread.sleep(600);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());

		// Click on building dropdown list and select value "Building01S01"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(600);
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());

		// Click on Alert Configuration tab
		getComposerPages().homePage().selectTab(TAB_OPTIONS.AlertConfiguration.getValue()).click();

		// click on Add tab under "Alert Configuration"
		getComposerPages().homePage().selectSubTab(SUB_TAB_OPTIONS.Add.getName()).click();

		// Select option Family
		getComposerPages().alertConfigurationPage().optionSelectionOnAddAlertConfig("Family").click();

		// Click on family drop down list and select "Family2"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().alertConfigurationPage().familyDropDownOnAddAlertConfig()));
		getComposerPages().alertConfigurationPage().familyDropDownOnAddAlertConfig().click();
		Thread.sleep(800);
		getComposerPages().alertConfigurationPage().selectListFamilyOptionByName(FAMILY.Family2.getName());

		// Click on property drop down list and select "Battery"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().alertConfigurationPage().propertyDropDownOnAddAlertConfig()));
		getComposerPages().alertConfigurationPage().propertyDropDownOnAddAlertConfig().click();
		Thread.sleep(800);
		getComposerPages().alertConfigurationPage().selectListPropertyOptionByName(PROPERTY.Battery.getName());

		// Enter Alert name
		getComposerPages().alertConfigurationPage().alertName().sendKeys(alertName);

		// Alert Type
		getComposerPages().alertConfigurationPage().alertTypeSelectionOnAddAlertConfig("Above").click();

		// Enter Alert Value
		getComposerPages().alertConfigurationPage().alertValueOnAddAlertConfig().sendKeys(alertValue);

		// Click on alert "Add" button
		getComposerPages().alertConfigurationPage().add().click();
		Thread.sleep(1000);

		// Verify that alert configuration is successfully added
		if (getComposerPages().homePage().statusMessage().equals("Alert Config successfully added for family.")) {
			Assert.assertEquals("Alert Config successfully added for family.",
					getComposerPages().homePage().statusMessage());
		}
	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}
}