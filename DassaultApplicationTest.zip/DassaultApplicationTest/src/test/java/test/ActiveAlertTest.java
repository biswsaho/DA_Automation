package test;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class ActiveAlertTest extends TestBase{

	private final String alertName = "TemperatureAlert";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}
	
	@org.testng.annotations.Test
	public void activeAlertTest() throws InterruptedException, IOException {
		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(30)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class, ElementClickInterceptedException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(10000);
		
		// Click on site dropdown list and select value "Site01"
		wait.until(
				ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getSiteDropDown()));
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		Thread.sleep(8000);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());

		// Click on building dropdown list and select value "Building01S01"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(8000);
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());
		
		//Click on Active Alert tab		
		getComposerPages().homePage().selectTab(TAB_OPTIONS.Alert.getValue()).click();
		getComposerPages().homePage().getAlertSubTab(SUB_TAB_OPTIONS.Active.getName()).click();
		//click on calender
		getComposerPages().activeAlertsPage().clickOnCalendar().click();
		Thread.sleep(3000);	
		getComposerPages().activeAlertsPage().clickOnMonthDropdown().click();
		Thread.sleep(8000);

		getComposerPages().activeAlertsPage().selectDesiredMonth("January");
		Thread.sleep(6000);
		getComposerPages().activeAlertsPage().clickOnYearDropdown().click();

		getComposerPages().activeAlertsPage().selectDesiredYear("2022");
		Thread.sleep(6000);
		getComposerPages().activeAlertsPage().clickOnDateValue("10");
		/*Thread.sleep(6000);
		
		getComposerPages().activeAlertsPage().clickOnHour().click();
		Thread.sleep(6000);
		
		getComposerPages().activeAlertsPage().selectDesiredHour("4");
		*/

		getComposerPages().activeAlertsPage().clickOnDone().click();
		Thread.sleep(6000);

		getComposerPages().activeAlertsPage().clickOnEndDateCalendar().click();
		Thread.sleep(3000);	
		getComposerPages().activeAlertsPage().clickOnMonthEndDropdown().click();
		Thread.sleep(8000);
		getComposerPages().activeAlertsPage().selectDesiredEndMonth("March");
		Thread.sleep(6000);
		getComposerPages().activeAlertsPage().clickOnEndYearDropdown().click();

		getComposerPages().activeAlertsPage().selectDesiredEndYear("2021");
		Thread.sleep(6000);
		getComposerPages().activeAlertsPage().clickOnEndDateValue("2");
		Thread.sleep(6000);
		getComposerPages().activeAlertsPage().clickOnEndDone().click();
		Thread.sleep(6000);
		
		//element is present and displayed
		//Thread.sleep(100);
		//Assert.assertTrue(getComposerPages().activeAlertsPage().CalenderValue()
		if (getComposerPages().homePage().errorMessage().equals("Start Date should be lesser than End date. Choose correct date.")) {
			Assert.assertEquals("Start Date should be lesser than End date. Choose correct date.",
					getComposerPages().homePage().errorMessage());
			System.out.println("Start Date should be lesser than End date. Choose correct date.");
		}
		getComposerPages().homePage().dismissButton().click();
		getComposerPages().activeAlertsPage().SelectElementOnActiveAlertTable(alertName).click();
		Thread.sleep(100);
		Assert.assertTrue(getComposerPages().activeAlertsPage().SelectElementOnActiveAlertTable(alertName).isDisplayed(),"Alert Name is not present in active tab"); 		
	}
	
	@AfterClass
	private void afterClass() {
		tearDown();
	
}
}