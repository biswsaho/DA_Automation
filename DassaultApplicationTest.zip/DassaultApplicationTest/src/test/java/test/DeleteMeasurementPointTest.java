package test;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class DeleteMeasurementPointTest extends TestBase {
	private final String measurementPoint = "MP100";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void deleteMeasurementPointTest() throws InterruptedException, IOException {
		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(8000);

		// Click on Site Drop down and select the site "Site01"
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());

		// Click on the Building Drop down and select the building "Building01S01"
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());

		// Select "Delete Measurement Point" tab
		// getComposerPages().homePage().getMPTabNew(MP_TAB_OPTIONS.MPConfiguration.getValue()).click();
		getComposerPages().homePage().selectTab(TAB_OPTIONS.MPConfiguration.getValue()).click();

		getComposerPages().homePage().selectMeasurementPointFromTable("55").click();
		// Thread.sleep(6000);

		// Click on remove button
		getComposerPages().deleteMeasurementPointPage().DeleteButton().click();
		Thread.sleep(6000);

		// Verify measurement point deleted successfully
		if (getComposerPages().deleteMeasurementPointPage().check()
				.equals("Successfully deleted alert configuration for measurement family.")) {
			Assert.assertEquals("Successfully deleted alert configuration for measurement family.",
					getComposerPages().deleteMeasurementPointPage().check());
		}
	}

	@AfterClass
	private void afterClass() {
		tearDown();

	}
	
	
}
