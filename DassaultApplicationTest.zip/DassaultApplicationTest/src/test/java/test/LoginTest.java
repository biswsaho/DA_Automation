package test;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import base.TestBase;

public class LoginTest extends TestBase {

	@BeforeClass
	private void beforeClass() {
		initialization();
	}

	@org.testng.annotations.Test
	public void verifyLoginPage() throws InterruptedException {
		// Enter Username and Password into the login page
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		Thread.sleep(3000);

		getComposerPages().loginPage().getLoginButton().click();
		driver.navigate().refresh();
		Thread.sleep(5000);

		// Verify user is login to the system
		Assert.assertTrue(getComposerPages().loginPage().getUser().isDisplayed(), "User is not login to the system.");
	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}
}
