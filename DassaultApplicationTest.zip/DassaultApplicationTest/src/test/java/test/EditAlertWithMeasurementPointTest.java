package test;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class EditAlertWithMeasurementPointTest extends TestBase {

	private final String alertName = "Test";

	private final String alertValue = "";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void editAlertWithMeasurementPointTest() throws InterruptedException, IOException {

		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(6000);

		// Click on site dropdown list and select value "Site01"
		wait.until(ExpectedConditions.visibilityOf(getComposerPages().alertConfigurationPage().getSiteDropDown()));
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		Thread.sleep(4000);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());
		Thread.sleep(4000);

		// Click on building dropdown list and select value "Building01S01"
		wait.until(ExpectedConditions.visibilityOf(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(4000);
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());
		Thread.sleep(4000);

		// Click on Alert Configuration tab
		getComposerPages().homePage().selectTab(TAB_OPTIONS.AlertConfiguration.getValue()).click();
		Thread.sleep(3000);

		// Click on Add tab under "Alert Configuration"
		getComposerPages().homePage().selectSubTab(SUB_TAB_OPTIONS.Edit.getName()).click();
		Thread.sleep(4000);

		// Select option Family
		getComposerPages().editAlertConfigurationPage().optionSelectionOnEditAlertConfig("Measurement Point").click();
		Thread.sleep(6000);

		// Select Measurement Point from table
		getComposerPages().homePage().selectMeasurementPointFromTable("MP_ONE_ALERT").click();

		// Click on property drop down list and select "Battery"
		wait.until(ExpectedConditions.elementToBeClickable(
				getComposerPages().editAlertConfigurationPage().propertyDropDownOnEditAlertConfig()));
		getComposerPages().editAlertConfigurationPage().propertyDropDownOnEditAlertConfig().click();
		Thread.sleep(800);
		getComposerPages().alertConfigurationPage().selectListPropertyOptionByName(PROPERTY.Battery.getName());

		// Select Alert name
		wait.until(ExpectedConditions.elementToBeClickable(
				getComposerPages().editAlertConfigurationPage().alertNameDropDownOnEditWithMeasurementPoint()));
		getComposerPages().editAlertConfigurationPage().alertNameDropDownOnEditWithMeasurementPoint().click();
		Thread.sleep(4000);
		getComposerPages().editAlertConfigurationPage().selectListAlertOptionByName(alertName);

		// Alert Type
		getComposerPages().editAlertConfigurationPage().alertTypeSelectionOnEditWithMeasurementPoint("Above").click();
		Thread.sleep(4000);

		// Enter Alert Value
		getComposerPages().editAlertConfigurationPage().alertValueOnEditWithMeasurementPoint().sendKeys(alertValue);

		// Alert Add Button
		Thread.sleep(4000);
		getComposerPages().editAlertConfigurationPage().update().click();
        Thread.sleep(9000);
        if (getComposerPages().homePage().charError()
				.equals("Error while adding measurement point.")) {
			Assert.assertEquals("Error while adding measurement point.",
					getComposerPages().homePage().charError());
			//click on dismiss button
			wait.until(ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().dismiss()));
			getComposerPages().alertConfigurationPage().dismiss().click();
			
		}
		// Check whether test failed or passed
        else {
			Assert.assertEquals("Alert Configuration updated successfully",
					getComposerPages().editAlertConfigurationPage().check());
		}
        Thread.sleep(5000);
	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}
}
