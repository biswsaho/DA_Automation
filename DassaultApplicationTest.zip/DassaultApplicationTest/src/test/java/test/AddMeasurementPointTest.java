package test;

import java.io.IOException;
import java.time.Duration;


import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class AddMeasurementPointTest extends TestBase {

	
	private final String measurementPoint = "MP45";
	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}
	
	@org.testng.annotations.Test
	public void addMeasurementPointTest() throws InterruptedException, IOException {
		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(10000);

		// Click on site dropdown list and select value "Site01"
		wait.until(
				ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getSiteDropDown()));
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		Thread.sleep(800);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());

		// Click on building dropdown list and select value "Building01S01"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(8000);
		getComposerPages().alertConfigurationPage().selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());
		
		//Click on MP Configuration tab		
		getComposerPages().homePage().selectTab(TAB_OPTIONS.MPConfiguration.getValue()).click();

		Thread.sleep(7000);
		//Click on Family dropdown list and select value "Family2"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().addMeasurementPointPage().familyDropDowninMP()));
		getComposerPages().addMeasurementPointPage().familyDropDowninMP().click();
		Thread.sleep(10000);
		getComposerPages().addMeasurementPointPage().selectFamilyDropdownListinMP(FAMILY.Family2.getName());
		Thread.sleep(800);
		
		//Click on Measurement Point dropdown list and select value "MP20"
		getComposerPages().addMeasurementPointPage().measurementPoint().sendKeys(measurementPoint);
		
		// Click on Measurement Point "Add" button
		getComposerPages().addMeasurementPointPage().add().click();
		Thread.sleep(1000);

		// Verify that Measurement Point is successfully added
		if (getComposerPages().homePage().statusMessage().equals("MeasurementPoint  successfully added for family.")) {
			Assert.assertEquals("Measurement point  successfully added.",
					getComposerPages().homePage().statusMessage());
			System.out.println("Test Passed: Measurement Point Added");
		}
		else if(getComposerPages().homePage().statusMessage().equals("Measurement Point Already Exist")) {
			Assert.assertEquals("Measurement Point Already Exist",
					getComposerPages().homePage().statusMessage());
			System.out.println("Test Passed: Measurement Point Already Exist");

		}
				
		Thread.sleep(9000);

		getComposerPages().addMeasurementPointPage().selectMeasurementPointFromTable(measurementPoint).click();
		Thread.sleep(9000);
		Assert.assertTrue(getComposerPages().addMeasurementPointPage().selectMeasurementPointFromTable(measurementPoint).isDisplayed(),"Measurement Point is not present in active tab"); 		
        
	}		
	
		//@AfterClass
	private void afterClass() {
		tearDown();
}
		
}