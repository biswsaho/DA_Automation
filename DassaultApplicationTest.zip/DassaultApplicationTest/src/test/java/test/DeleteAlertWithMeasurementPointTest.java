package test;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class DeleteAlertWithMeasurementPointTest extends TestBase {
	private final String alertName = "BatteryAlert";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void deleteAlertWithMeasurementPointTest() throws InterruptedException, IOException {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(8000);
		

		// Click on Site Drop down and select the site "Site01"
		wait.until(
				ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getSiteDropDown()));
				getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		Thread.sleep(3000);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());

		// Click on the Building Drop downand select the building "Building01S01"
		wait.until(
				ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(4000);
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());

		// Select "Alert Configuration" tab
		getComposerPages().homePage().selectTab(TAB_OPTIONS.AlertConfiguration.getValue()).click();
		Thread.sleep(4000);

		// Select "Delete" sub tab
		getComposerPages().homePage().selectSubTab(SUB_TAB_OPTIONS.Delete.getName()).click();
		Thread.sleep(5000);

		// Select Family option
		getComposerPages().deleteAlertConfigurationPage().optionSelectionOnDeleteAlertConfig("Measurement Point")
				.click();
		Thread.sleep(6000);

		// Select Measurement Point from table
		getComposerPages().homePage().selectMeasurementPointFromTable("MPTest01").click();
		Thread.sleep(4000);
		
		getComposerPages().deleteAlertConfigurationPage().MeasurementPointText().sendKeys("MPte");

		// Click on Property Name drop down and select "Battery"
		getComposerPages().deleteAlertConfigurationPage().PropertyName().click();
		Thread.sleep(4000);
		
		getComposerPages().alertConfigurationPage().selectListPropertyOptionByName(PROPERTY.Battery.getName());
		Thread.sleep(9000);

		// Select Element from table
		getComposerPages().homePage().deleteMesTableElement(alertName).click();
		Thread.sleep(5000);

		// Click on delete button
		getComposerPages().deleteAlertConfigurationPage().DeleteButton().click();
		Thread.sleep(9000);


		if (getComposerPages().deleteAlertConfigurationPage().check()
		.equals("Successfully deleted alert configuration for measurement family.")) {
		Assert.assertEquals("Alert configuration successfully deleted for Measurement Point",
		getComposerPages().deleteAlertConfigurationPage().check());
		}
		else if(getComposerPages().deleteAlertConfigurationPage().check()
		.equals("Error while deleting alert configuration.")) {
		Assert.assertEquals("Error while deleting alert configuration.",
		getComposerPages().deleteAlertConfigurationPage().check());
		}

	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}

}

