package test;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;


public class InactiveAlertTest extends TestBase{
	private final String alertName = "LowTempDemoAlertOne";
	
	private final String alertValue = "20";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}
	
	@org.testng.annotations.Test
	public void addNewAlertConfigurationTest() throws InterruptedException, IOException {
		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(6000);

		// Click on site dropdown list and select value "Site01"
				wait.until(
						ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getSiteDropDown()));
				getComposerPages().alertConfigurationPage().getSiteDropDown().click();
				Thread.sleep(600);
				getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());
				
				// Click on building dropdown list and select value "Building01S01"
				wait.until(ExpectedConditions
						.elementToBeClickable(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
				getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
				Thread.sleep(600);
				getComposerPages().alertConfigurationPage()
						.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());

				
				// Click on Alert tab
				getComposerPages().homePage().selectTab(TAB_OPTIONS.Alert.getValue()).click();
				

				// click on Inactive tab under "Alert"
				getComposerPages().homePage().getAlertSubTab(SUB_TAB_OPTIONS.Inactive.getName()).click();
				
				getComposerPages().inactiveAlertPage().clickOnCalendar().click();
				Thread.sleep(3000);
				getComposerPages().inactiveAlertPage().clickOnMonthDropdown().click();
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().selectDesiredMonth("January");
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().clickOnYearDropdown().click();
				getComposerPages().inactiveAlertPage().selectDesiredYear("2022");
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().clickOnDateValue("10");
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().clickOnDone().click();
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().clickOnEndDateCalendar().click();
				Thread.sleep(3000);
				getComposerPages().inactiveAlertPage().clickOnMonthEndDropdown().click();
				Thread.sleep(8000);
				getComposerPages().inactiveAlertPage().selectDesiredEndMonth("March");
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().clickOnEndYearDropdown().click();

				getComposerPages().inactiveAlertPage().selectDesiredEndYear("2022");
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().clickOnEndDateValue("2");
				Thread.sleep(6000);
				getComposerPages().inactiveAlertPage().clickOnEndDone().click();
				Thread.sleep(6000);
		
				if (getComposerPages().homePage().errorMessage().equals("Start Date should be lesser than End date. Choose correct date.")) {
					Assert.assertEquals("Start Date should be lesser than End date. Choose correct date.",
							getComposerPages().homePage().errorMessage());
					System.out.println("Start Date should be lesser than End date. Choose correct date.");
				}
				getComposerPages().homePage().dismissButton().click();
				getComposerPages().inactiveAlertPage().SelectElementOninactiveAlertTable(alertName).click();
				
				//element is present and displayed
				Assert.assertTrue(getComposerPages().inactiveAlertPage().SelectElementOninactiveAlertTable(alertName).isDisplayed());
				
				
				}

	@AfterClass
	private void afterClass() {
		tearDown();

	}
	
}
