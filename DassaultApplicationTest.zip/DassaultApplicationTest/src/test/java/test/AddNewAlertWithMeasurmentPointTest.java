package test;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import Pages.AlertConfigurationPage;
import base.TestBase;

public class AddNewAlertWithMeasurmentPointTest extends TestBase {

	private final String alertName = "";

	private final String alertValue = "44";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void addNewAlertWithMeasurmentPointTest() throws InterruptedException, IOException {
		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(8000);

		// Click on site dropdown list and select value "Site01"
		wait.until(
				ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getSiteDropDown()));
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		Thread.sleep(6000);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());
		Thread.sleep(9000);
		// Click on building dropdown list and select value "Building01S01"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(6000);
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());
		Thread.sleep(5000);

		// Click on Alert Configuration tab
		getComposerPages().homePage().selectTab(TAB_OPTIONS.AlertConfiguration.getValue()).click();
		Thread.sleep(3000);

		// click on Add tab under "Alert Configuration"
		getComposerPages().homePage().selectSubTab(SUB_TAB_OPTIONS.Add.getName()).click();
		Thread.sleep(3000);

		// Select option "Measurement Point"
		getComposerPages().alertConfigurationPage().optionSelectionOnAddAlertConfig("Measurement Point").click();
		Thread.sleep(4000);

		// Select Measurement Point from table
		getComposerPages().homePage().selectMeasurementPointFromTable("MP_ONE_ALERT").click();
		Thread.sleep(4000);

		// Click on property drop down list and select "Battery"
		wait.until(ExpectedConditions
				.elementToBeClickable(getComposerPages().alertConfigurationPage().propertyDropDownOnAddAlertConfig()));
		getComposerPages().alertConfigurationPage().propertyDropDownOnAddAlertConfig().click();
		Thread.sleep(800);
		getComposerPages().alertConfigurationPage().selectListPropertyOptionByName(PROPERTY.Battery.getName());

		// Enter Alert name
		getComposerPages().alertConfigurationPage().alertName().sendKeys(alertName);

		// Alert Type
		getComposerPages().alertConfigurationPage().alertTypeSelectionOnAddAlertConfig("Above").click();

		// Enter Alert Value
		getComposerPages().alertConfigurationPage().alertValueOnAddAlertConfig().sendKeys(alertValue);

		// Click on alert "Add" button
		getComposerPages().alertConfigurationPage().addAlertWithMeaurement().click();
		Thread.sleep(4000);
		
		//verify the error message for invalid input, if we give blank for alertname 
		
		if (getComposerPages().homePage().charError()
				.equals("Error while adding measurement point.")) {
			Assert.assertEquals("Error while adding measurement point.",
					getComposerPages().homePage().charError());
			//click on dismiss button
			wait.until(ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().dismiss()));
			getComposerPages().alertConfigurationPage().dismiss().click();
		}
		else if(getComposerPages().homePage().charError().equals("Alert Name should not contain any other special character except '_' .")) {
			Assert.assertEquals("Alert Name should not contain any other special character except '_' .",
					getComposerPages().homePage().charError());
			//click on dismiss button
			wait.until(ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().dismiss()));
			getComposerPages().alertConfigurationPage().dismiss().click();
			
			
		}
		else {
			Assert.assertEquals("Alert configuration successfully added for measurement point",
					getComposerPages().homePage().statusMessage());
			
		}
		
		Thread.sleep(5000);
		
		
	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}
}
