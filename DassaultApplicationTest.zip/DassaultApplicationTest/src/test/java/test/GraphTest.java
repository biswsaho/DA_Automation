
package test;

import java.io.IOException;
import java.time.Duration;


import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;
import common.utilities.ScreenCapture;

public class GraphTest extends TestBase {
	


	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void graphTest() throws InterruptedException, IOException {
		// Add wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(60))
				.pollingEvery(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(8000);

		// Click on Site Drop down and select the site "Site01"
		wait.until(ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getSiteDropDown()));
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
	    Thread.sleep(6000);
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());
		Thread.sleep(5000);

		// Click on the Building Drop downand select the building "Building01S01"
		wait.until(ExpectedConditions.elementToBeClickable(getComposerPages().alertConfigurationPage().getBuildingDropDown()));
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		Thread.sleep(4000);
        getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());
        Thread.sleep(4000);
        
		// click on graph tab
        getComposerPages().homePage().selectTab(TAB_OPTIONS.Graph.getValue()).click();
		Thread.sleep(9000);
		
		//click on calendar table
	    getComposerPages().graphPage().clickOnCalendar().click();
		Thread.sleep(3000);
		
		//click on Month Dropdown
		getComposerPages().graphPage().clickOnMonthDropdown().click();
		Thread.sleep(8000);
		
		//select September month
		getComposerPages().graphPage().selectDesiredMonth("September");
		Thread.sleep(3000);
			
		
		//click on year dropdown
		getComposerPages().graphPage().clickOnYearDropdown().click();
		Thread.sleep(3000);
		
		//select 2019 year
		getComposerPages().graphPage().selectYear("2021");
		Thread.sleep(5000);
		//getComposerPages().graphPage().selectDesiredDate("12");
		
		//click on date
		//getComposerPages().graphPage().clickOnDateValue().click();
		getComposerPages().graphPage().clickOnStartDateValue("16");
		Thread.sleep(4000);
		
		//click on Done button
		getComposerPages().graphPage().clickOnDone().click();
		
		
		//click on EndDate Table
		wait.until(
				ExpectedConditions.elementToBeClickable(getComposerPages().graphPage().clickOnEndDate()));
		getComposerPages().graphPage().clickOnEndDate().click();
		Thread.sleep(5000);
		
		//click on end month dropdown
		getComposerPages().graphPage().clickOnEndMonthDropdown().click();
		Thread.sleep(5000);
		
		//selecting the month
		getComposerPages().graphPage().selectDesiredEndMonth("April");
		Thread.sleep(4000);
		
		//click on endYearDropdown
		getComposerPages().graphPage().clickOnEndYearDropdown().click();
		Thread.sleep(4000);
		
		//selecting the year
		getComposerPages().graphPage().selectEndYear("2019");
		Thread.sleep(4000);
		
		//clicking on 10th date
	    getComposerPages().graphPage().clickOnEndDateValue("12");
		Thread.sleep(4000);
		
		
		//clicking on done button
		getComposerPages().graphPage().clickOnDoneToDate().click();
		Thread.sleep(8000);
		//checking the status message
		if (getComposerPages().graphPage().check()
				.equals("Start Date should be lesser than End date. Choose correct date.")) {
			Assert.assertEquals("Start Date should be lesser than End date. Choose correct date.",
					getComposerPages().graphPage().check());
			
		}
		
		Thread.sleep(6000);
		//clicking on dismiss button
		getComposerPages().graphPage().dismiss().click();
		Thread.sleep(4000);
		
		// Click on measurementpoint
		getComposerPages().homePage().selectMeasurementPointFromTable("MPTest01").click();
		Thread.sleep(6000);
		ScreenCapture.captureScreenshot(driver, "graphScreenShot");
		Thread.sleep(3000);
	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}
}
