package test;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Pages.HomePage.BUILDING_OPTIONS;
import Pages.HomePage.FAMILY;
import Pages.HomePage.PROPERTY;
import Pages.HomePage.SITE_OPTIONS;
import Pages.HomePage.SUB_TAB_OPTIONS;
import Pages.HomePage.TAB_OPTIONS;
import base.TestBase;

public class DeleteAlertConfigurationTest extends TestBase {
	private final String alertName = "LowTempDemoAlertOne";

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void deleteAlertConfigurationTest() throws InterruptedException, IOException {

		// Login to the application
		getComposerPages().loginPage().getEmailInputBox().sendKeys(prop.getProperty("username"));
		getComposerPages().loginPage().getPasswordInputBox().sendKeys(prop.getProperty("password"));
		getComposerPages().loginPage().getLoginButton().click();
		Thread.sleep(8000);

		// Click on Site Drop down and select the site "Site01"
		getComposerPages().alertConfigurationPage().getSiteDropDown().click();
		getComposerPages().alertConfigurationPage().selectListSiteOptionByName(SITE_OPTIONS.Site01.getName());

		// Click on the Building Drop downand select the building "Building01S01"
		getComposerPages().alertConfigurationPage().getBuildingDropDown().click();
		getComposerPages().alertConfigurationPage()
				.selectListBuildingOptionByName(BUILDING_OPTIONS.Building01S01.getName());

		// Select "Alert Configuration" tab
		getComposerPages().homePage().selectTab(TAB_OPTIONS.AlertConfiguration.getValue()).click();

		// Select "Delete" sub tab
		getComposerPages().homePage().selectSubTab(SUB_TAB_OPTIONS.Delete.getName()).click();

		// Select Family option
		getComposerPages().deleteAlertConfigurationPage().optionSelectionOnDeleteAlertConfig("Family").click();

		// Click on Family Name drop down and select "Family2"
		getComposerPages().deleteAlertConfigurationPage().FamilyDropdown().click();
		getComposerPages().alertConfigurationPage().selectListFamilyOptionByName(FAMILY.Family2.getName());

		// Click on Property Name drop down and select "Battery"
		getComposerPages().deleteAlertConfigurationPage().PropertyName().click();
		getComposerPages().alertConfigurationPage().selectListPropertyOptionByName(PROPERTY.Battery.getName());

		// Select Element from table
		getComposerPages().homePage().deleteTableElement(alertName).click();

		// Click on delete button
		getComposerPages().deleteAlertConfigurationPage().DeleteButton().click();

		// Verify alert configuration deleted successfully
		if (getComposerPages().deleteAlertConfigurationPage().check()
				.equals("Successfully deleted alert configuration for measurement family.")) {
			Assert.assertEquals("Successfully deleted alert configuration for measurement family.",
					getComposerPages().deleteAlertConfigurationPage().check());
		}
	}

	@AfterClass
	private void afterClass() {
		tearDown();
	}
}