package common.utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import base.TestBase;

public class TestListener extends TestBase implements ITestListener {

	public void onStart(ITestContext context) {
		System.out.println("Test Suite " + context.getName() + " started");
	}

	public void onFinish(ITestContext context) {
		System.out.println(("Test Suite " + context.getName() + " finished"));
		ExtentTestManager.endTest();
		ExtentManager.getInstance().flush();
	}

	public void onTestStart(ITestResult result) {
		System.out.println(("Test " + result.getMethod().getMethodName() + " started."));
		ExtentTestManager.startTest(result.getMethod().getMethodName());
	}

	public void onTestSuccess(ITestResult result) {
		System.out.println("Test " + result.getMethod().getMethodName() + " passed.");
		ExtentTestManager.getTest().log(Status.PASS, "Test Passed");
	}

	public void onTestFailure(ITestResult result) {
		System.out.println("Test " + result.getMethod().getMethodName() + " failed!");

		// Take screenshot on failure
		String targetLocation = null;
		String testClassName = (result.getInstanceName()).trim();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
		Date date = new Date();
		String timeStamp = formatter.format(date);
		String fileSeperator = System.getProperty("file.separator");
		try {
			File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			targetLocation = System.getProperty("user.dir") + fileSeperator + "TestReport" + fileSeperator
					+ "FailedTests" + fileSeperator + testClassName + fileSeperator + result.getName().toString().trim()
					+ timeStamp + ".jpg";
			File targetFile = new File(targetLocation);
			FileUtils.copyFile(screenshotFile, targetFile);
		} catch (FileNotFoundException e) {
			System.out.println("File not found exception occurred while taking screenshot " + e.getMessage());
		} catch (Exception e) {
			System.out.println("An exception occurred while taking screenshot " + e.getCause());
		}

		// Attach screenshot to report
		try {
			ExtentTestManager.getTest().fail("Screenshot",
					MediaEntityBuilder.createScreenCaptureFromPath(targetLocation).build());

		} catch (IOException e) {
			System.out.println("An exception occured while taking screenshot " + e.getCause());
		}
		ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	}

	public void onTestSkipped(ITestResult result) {
		System.out.println("Test " + result.getMethod().getMethodName() + " skipped");
		ExtentTestManager.getTest().log(Status.SKIP, "Test Skipped");
	}
}