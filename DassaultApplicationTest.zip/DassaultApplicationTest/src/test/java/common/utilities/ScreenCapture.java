package common.utilities;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import base.TestBase;

public class ScreenCapture extends TestBase {
	static String folderLocation = prop.getProperty("reportDirectoryPath") + "/" + "VisualReport";

	public static void captureScreenshot(WebDriver driver, String fileName) {
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			File dest = new File(folderLocation + "/" + fileName + ".jpg");
			FileUtils.copyFile(source, dest);
		} catch (Exception e) {
			System.out.println("Exception while taking screenshot " + e.getMessage());
		}
	}
}
