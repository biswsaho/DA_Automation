package common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Pages.ActiveAlertsPage;
import Pages.AddMeasurementPointPage;
import Pages.AlertConfigurationPage;
import Pages.DeleteAlertConfigurationPage;
import Pages.DeleteMeasurementPointPage;
import Pages.EditAlertConfigurationPage;
import Pages.Graph;
import Pages.HomePage;
import Pages.InactiveAlertPage;
import Pages.LoginPage;

public class ComposerPageFactory {

	private WebDriver driver;
	private By by;

	public ComposerPageFactory(WebDriver webdriver) {
		this.driver = webdriver;
	}

	// ********* PAGES INSTANTIATION LIST - START *******************

	private LoginPage loginPage = null;

	public LoginPage loginPage() {
		if (null == loginPage) {
			loginPage = new LoginPage(driver);
		}
		return loginPage;
	}

	private AlertConfigurationPage alertConfigurationPage = null;

	public AlertConfigurationPage alertConfigurationPage() {
		if (null == alertConfigurationPage) {
			alertConfigurationPage = new AlertConfigurationPage(driver);
		}
		return alertConfigurationPage;
	}

	private HomePage homePage = null;

	public HomePage homePage() {
		if (null == homePage) {
			homePage = new HomePage(driver);
		}
		return homePage;
	}

	private DeleteAlertConfigurationPage deleteAlertConfigurationPage = null;

	public DeleteAlertConfigurationPage deleteAlertConfigurationPage() {
		if (null == deleteAlertConfigurationPage) {
			deleteAlertConfigurationPage = new DeleteAlertConfigurationPage(driver);
		}
		return deleteAlertConfigurationPage;
	}

	private EditAlertConfigurationPage editAlertConfigurationPage = null;

	public EditAlertConfigurationPage editAlertConfigurationPage() {
		if (null == editAlertConfigurationPage) {
			editAlertConfigurationPage = new EditAlertConfigurationPage(driver);
		}
		return editAlertConfigurationPage;
	}
	
	private AddMeasurementPointPage addMeasurementPointPage =null;
	
	public AddMeasurementPointPage addMeasurementPointPage() {
		
		if(null == addMeasurementPointPage) {
			addMeasurementPointPage = new AddMeasurementPointPage(driver);
		}
		return addMeasurementPointPage;
	}
	
	private DeleteMeasurementPointPage deleteMeasurementPointPage = null;

	public DeleteMeasurementPointPage deleteMeasurementPointPage() {
		if (null == deleteMeasurementPointPage) {
			deleteMeasurementPointPage = new DeleteMeasurementPointPage(driver);
		}
		return deleteMeasurementPointPage;
	}
	private ActiveAlertsPage activeAlertsPage =null;
	
	public ActiveAlertsPage activeAlertsPage() {
		
		if(null == activeAlertsPage) {
			activeAlertsPage = new ActiveAlertsPage(driver);
		}
		return activeAlertsPage;
	}
	
	private InactiveAlertPage inactiveAlertPage = null;

	public InactiveAlertPage inactiveAlertPage() {
		if (null == inactiveAlertPage) {
			inactiveAlertPage = new InactiveAlertPage(driver);
		}
		return inactiveAlertPage;
	}
	private Graph graphPage = null;

	public Graph graphPage() {
		if (null == graphPage) {
			graphPage = new Graph(driver);
		}
		return graphPage;
	}
	
	// ************* PAGES INSTANTIATION LIST - END *******************
}