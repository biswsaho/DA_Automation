package common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Pages.AlertConfigurationPage;
import Pages.DeleteAlertConfigurationPage;
import Pages.EditAlertConfigurationPage;
import Pages.HomePage;
import Pages.LoginPage;

public class ComposerPageFactory {

	private WebDriver driver;
	private By by;

	public ComposerPageFactory(WebDriver webdriver) {
		this.driver = webdriver;
	}

	// ********* PAGES INSTANTIATION LIST - START *******************

	private LoginPage loginPage = null;

	public LoginPage loginPage() {
		if (null == loginPage) {
			loginPage = new LoginPage(driver);
		}
		return loginPage;
	}

	private AlertConfigurationPage alertConfigurationPage = null;

	public AlertConfigurationPage alertConfigurationPage() {
		if (null == alertConfigurationPage) {
			alertConfigurationPage = new AlertConfigurationPage(driver);
		}
		return alertConfigurationPage;
	}

	private HomePage homePage = null;

	public HomePage homePage() {
		if (null == homePage) {
			homePage = new HomePage(driver);
		}
		return homePage;
	}

	private DeleteAlertConfigurationPage deleteAlertConfigurationPage = null;

	public DeleteAlertConfigurationPage deleteAlertConfigurationPage() {
		if (null == deleteAlertConfigurationPage) {
			deleteAlertConfigurationPage = new DeleteAlertConfigurationPage(driver);
		}
		return deleteAlertConfigurationPage;
	}

	private EditAlertConfigurationPage editAlertConfigurationPage = null;

	public EditAlertConfigurationPage editAlertConfigurationPage() {
		if (null == editAlertConfigurationPage) {
			editAlertConfigurationPage = new EditAlertConfigurationPage(driver);
		}
		return editAlertConfigurationPage;
	}

	// ************* PAGES INSTANTIATION LIST - END *******************
}