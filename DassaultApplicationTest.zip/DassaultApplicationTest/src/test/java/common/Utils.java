package common;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utils {
	private By by;
	private WebDriver driver;

	private WebElement we;

	public By getBy() {
		return by;
	}

	public Utils(WebDriver driver, By by) {
		this.driver = driver;
		this.by = by;
		we = null;
		if (driver != null && by != null) {
			setWebElement();
		}
	}

	public WebElement getWebElement() {
		if (we == null) {
			setWebElement();
		}
		return we;
	}

	private void setWebElement() {
		try {
			we = getWebDriverFluentWait().until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {
			we = null;
		}
	}

	public FluentWait<WebDriver> getWebDriverFluentWait() {

		final String getWaitTimeout = System.getProperty("webdriver.explicit.wait");
		long waitTimeout;

		// Initialize the wait timeout from system properties
		if ((getWaitTimeout != null) && !getWaitTimeout.isEmpty()) {
			waitTimeout = Long.parseLong(getWaitTimeout);
		} else {
			// Setting a default value
			waitTimeout = TimeUnit.SECONDS.toSeconds(10);
		}

		final String getPollInterval = System.getProperty("pollInterval");
		long pollInterval;

		// Initialize the wait from system properties
		if ((getPollInterval != null) && !getPollInterval.isEmpty()) {
			pollInterval = Long.parseLong(getPollInterval);
		} else {
			// Setting a default value
			pollInterval = TimeUnit.MILLISECONDS.toMillis(1000);
		}

		return new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(waitTimeout))
				.pollingEvery(Duration.ofMillis(pollInterval)).ignoring(NoSuchElementException.class);
	}

	public WebDriverWait getWebDriverWait() {
		long time = Long.parseLong(System.getProperty("webdriver.explicit.wait"));
		return new WebDriverWait(driver, time);
	}

	public void waitForVisibilityOfElement() {
		getWebDriverFluentWait().until(ExpectedConditions.visibilityOfElementLocated(getBy()));
	}

}