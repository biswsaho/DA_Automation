package com.cg.helperlib.login;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.cg.base.testBase;
import com.cg.pages.locators.LoginPageLocators;

public class LoginTest extends testBase {

	@BeforeClass
	private void beforeClass() {
		initialization();
	}

	@org.testng.annotations.Test
	public void verifyLoginPage() throws InterruptedException {
		// Verify login page should be appear and its components are present
		LoginPageLocators login = new LoginPageLocators(driver);
		login.getEmailInputBox().sendKeys("Admin");
		login.getPasswordInputBox().sendKeys("Capgemini@1234");
		Thread.sleep(3000);
		login.getLoginButton().click();
		driver.navigate().refresh();
		Thread.sleep(5000);
		// String errorMessage = login.errorElement().getText();
		/*
		 * Assert.assertEquals( "Credentials do not match a valid " + "username-password
		 * combination for this " + "Organization. Try again." ,errorMessage);
		 ***/
	}

}
