package com.cg.pages.locators.family.test;

import com.cg.base.testBase;
import com.cg.pages.constants.Common;
import com.cg.pages.locators.LoginPageLocators;
import com.cg.pages.locators.family.AddFamilyLocators;
import com.cg.pages.locators.family.EditFamilyLocators;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class EditFamilyLocatorsTest extends testBase {
	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();

		if (descriptive == null) {

			System.out.println("Enter the option you wish to continue");
			System.out.println("Press 1 for descriptive results");
			System.out.println("Press 2 for direct results");

			String answer;
			Scanner sc = new Scanner(System.in);
			answer = sc.nextLine();

			if (answer.equals("1")) {
				changeDescriptiveTrue();
			} else if (answer.equals("2")) {
				changeDescriptiveFalse();
			} else {
				System.out.println("Enter the correct option.");
				System.exit(0);
			}
		}
	}

	@org.testng.annotations.Test
	public void verifyLoginPage() throws InterruptedException, IOException {

		String fileName = prop.getProperty("excelurl");

		File file = new File(fileName);
		FileInputStream fis = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheet(prop.getProperty("createSheetFamily"));

		int rowCount = ws.getLastRowNum();
		int rowNo = rowCount+2;
		XSSFRow rn1 = ws.createRow((short) rowNo++);
		XSSFRow rn2 = ws.createRow((short) rowNo++);
		XSSFRow rn3 = ws.createRow((short) rowNo++);
		XSSFRow rn4 = ws.createRow((short) rowNo++);
		XSSFRow rn5 = ws.createRow((short) rowNo++);
		XSSFRow rn6 = ws.createRow((short) rowNo++);
		XSSFRow rn7 = ws.createRow((short) rowNo++);
		XSSFRow rn8 = ws.createRow((short) rowNo++);
		XSSFRow rn9 = ws.createRow((short) rowNo++);
		XSSFRow rn10 = ws.createRow((short) rowNo++);
		XSSFRow rn11 = ws.createRow((short) rowNo++);
		XSSFRow rn12 = ws.createRow((short) rowNo++);
		XSSFRow rn13 = ws.createRow((short) rowNo++);
		XSSFRow rn14 = ws.createRow((short) rowNo++);

		rn1.createCell(0).setCellValue("Edit Alert At Family");
		LoginPageLocators login = new LoginPageLocators(driver);
		login.getEmailInputBox().sendKeys(prop.getProperty("username"));
		login.getPasswordInputBox().sendKeys(prop.getProperty("password"));
		try {
			rn2.createCell(0).setCellValue("Log In");
			rn2.createCell(1).setCellValue("Pass");
			login.getLoginButton().click();
			if (descriptive.equals("true")) {
				rn2.createCell(2).setCellValue("Pass");
			}
		} catch (Exception e) {
			rn2.createCell(2).setCellValue("Fail");
		}

		Thread.sleep(3000);

		EditFamilyLocators login1 = new EditFamilyLocators(driver);
		Thread.sleep(1000);

		Common newCommon = new Common(driver);

		// Site start
		Thread.sleep(3000);
		newCommon.getSiteDropDown().click();
		List<WebElement> SiteOptions = newCommon.getSiteDropDownList();

		WebElement siteOption = newCommon.checkList(SiteOptions, prop.getProperty("site01"));
		if (siteOption != null) {
			try {
				rn3.createCell(0).setCellValue("Site Name");
				rn3.createCell(1).setCellValue("Site Name is selected");
				siteOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Site Name is clicked");
					rn3.createCell(2).setCellValue("Site Name is selected");

				}
			} catch (Exception e) {
				System.out.println("Error in site name.");
				rn3.createCell(2).setCellValue("Fail");
			}

		} else {
			System.out.println("Error in site option.");
		}
		// Site end

		// Building start
		newCommon.getBuildingDropDown().click();

		List<WebElement> BuildingOptions = newCommon.getBuildingDropDownList();

		WebElement buildingOption = newCommon.checkList(BuildingOptions, prop.getProperty("building01S01"));

		if (buildingOption != null) {
			try {
				rn4.createCell(0).setCellValue("Building Name");
				rn4.createCell(1).setCellValue("Building Name is selected");
				buildingOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Building Name is clicked");
					rn4.createCell(2).setCellValue("Building Name is selected");
				}
			} catch (Exception e) {
				System.out.println("Error in Building name.");
				rn4.createCell(2).setCellValue("Error in Building name.");
			}

		} else {
			System.out.println("Error in building option.");
		}
		// Building end
		// tab
		List<WebElement> tab = new ArrayList<WebElement>();
		int i = 1;
		newCommon.selectTab(i);
		while (true) {
			try {
				WebElement tabNo = newCommon.selectTab(i);
				if (tabNo == null)
					break;
				tab.add(tabNo);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		boolean ans = false;
		for (int j = 0; j < tab.size(); j++) {

			if (tab.get(j).getText().equals(prop.getProperty("tabAlertConfiguration"))) {
				try {
					ans = true;
					rn5.createCell(0).setCellValue("Alert Configuration");
					rn5.createCell(1).setCellValue("Alert Configuration is selected");
					newCommon.selectTab(j + 1).click();
					if (descriptive.equals("true")) {
						System.out.println("Alert Configuration is clicked");
						rn5.createCell(2).setCellValue("Alert Configuration is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Alert Configuration.");
					rn5.createCell(2).setCellValue("Error in Alert Configuration");
				}

			} else {
				System.out.println("Error in Alert Configuration");
			}

		}

		List<WebElement> subTabOptions = newCommon.getSubTab();

		WebElement subTabValue = newCommon.checkList(subTabOptions, prop.getProperty("subtabEdit"));
		if (subTabValue != null) {
			try {
				rn6.createCell(0).setCellValue("Edit");
				rn6.createCell(1).setCellValue("Edit is selected");
				subTabValue.click();
				if (descriptive.equals("true")) {
					System.out.println("Edit is clicked");
					rn6.createCell(2).setCellValue("Edit");
				}
			} catch (Exception e) {
				System.out.println("Error in Edit.");
				rn6.createCell(2).setCellValue("Error in Edit");
			}
		}

		// Radio button
		WebElement radioButton = login1.familyRadioButton(prop.getProperty("radiobuttonFamily"));
		ans = false;
		try {
			ans = true;
			rn7.createCell(0).setCellValue("Family radio");
			rn7.createCell(1).setCellValue("Family radio is selected");
			radioButton.click();
			if (descriptive.equals("true")) {
				System.out.println("Family radio is clicked");
				rn7.createCell(2).setCellValue("Family radio is selected");
			}
		} catch (Exception e) {
			System.out.println("Error in Family radio");
			rn7.createCell(2).setCellValue("Error in Family radio");
		}

		List<WebElement> family = new ArrayList<WebElement>();
		i = 1;
		login1.familyDropDown().click();
		while (true) {
			try {
				WebElement familyValue = login1.familyDropDownValue(i);
				if (familyValue == null)
					break;
				family.add(familyValue);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		ans = false;
		for (int j = 0; j < family.size(); j++) {

			if (family.get(j).getText().equals(prop.getProperty("familynameFamily2"))) {
				try {
					ans = true;
					rn8.createCell(0).setCellValue("Family Value");
					rn8.createCell(1).setCellValue("Family Value is selected");
					login1.familyDropDownValue(j + 1).click();
					if (descriptive.equals("true")) {
						Thread.sleep(2000);
						System.out.println("Family Value is selected");
						rn8.createCell(2).setCellValue("Family Value is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Family Value");
					rn8.createCell(2).setCellValue("Error in Family Value");
				}
			}
		}
		List<WebElement> property = new ArrayList<WebElement>();
		i = 1;
		login1.propertyName().click();
		while (true) {
			try {
				WebElement propertyValue = login1.propertyNameValue(i);
				if (propertyValue == null)
					break;
				property.add(propertyValue);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		ans = false;
		for (int j = 0; j < property.size(); j++) {

			if (property.get(j).getText().equals(prop.getProperty("propertynameTemperature"))) {
				try {
					ans = true;
					rn9.createCell(0).setCellValue("Property Value");
					rn9.createCell(1).setCellValue("Property Value is selected");
					login1.propertyNameValue(j + 1).click();
					if (descriptive.equals("true")) {
						System.out.println("Property Value is selected");
						rn9.createCell(2).setCellValue("Property Value is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Property Value");
					rn9.createCell(2).setCellValue("Error in Property Value");
				}
			}
		}
		try {
			rn10.createCell(0).setCellValue("Alert Name");
			rn10.createCell(1).setCellValue("Alert Name is Vaild");
			login1.alertName().sendKeys(prop.getProperty("alertnameLowTempDemoAlert1"));
			if (descriptive.equals("true")) {
				System.out.println("Alert Name is Vaild");

				rn10.createCell(2).setCellValue("Alert Name is Vaild");
			}
		} catch (Exception e) {
			System.out.println("Error in Alert Name");
			rn10.createCell(2).setCellValue("Error in Alert Name");
		}
		try {
			rn11.createCell(0).setCellValue("Alert Type");
			rn11.createCell(1).setCellValue("Alert Type is selected");
			login1.alertType().click();
			if (descriptive.equals("true")) {
				System.out.println("Alert Type is selected");
				rn11.createCell(2).setCellValue("Alert Type is selected");
			}
		} catch (Exception e) {
			System.out.println("Error in Alert Type");
			rn11.createCell(2).setCellValue("Error in Alert Type");
		}
		try {
			rn12.createCell(0).setCellValue("Alert Value");
			rn12.createCell(1).setCellValue("Alert Value is valid");
			login1.alertValue().sendKeys(prop.getProperty("alertvalue"));
			if (descriptive.equals("true")) {
				System.out.println("Alert Value is valid");
				rn12.createCell(2).setCellValue("Alert Value is valid");
			}
		} catch (Exception e) {
			System.out.println("Error in Alert Value");
			rn12.createCell(2).setCellValue("Error in Alert Value");
		}
		try {
			rn13.createCell(0).setCellValue("Limit");
			rn13.createCell(1).setCellValue("Limit is selected");
			login1.limit().click();
			if (descriptive.equals("true")) {
				System.out.println("Limit is selected");
				rn13.createCell(2).setCellValue("Limit is selected");
			}
		} catch (Exception e) {
			System.out.println("Error in Limit");
			rn13.createCell(2).setCellValue("Error in Limit");
		}

		try {
			rn14.createCell(0).setCellValue("Update Button");
			rn14.createCell(1).setCellValue("Update Button is clicked");
			login1.update().click();
			if (descriptive.equals("true")) {
				System.out.println("Reached Family Alert Update Successfully.");
				rn14.createCell(2).setCellValue("Update Button is clicked");
			}
		} catch (Exception e) {
			System.out.println("Error in UpdateButton");
			rn14.createCell(2).setCellValue("Error in Update Button");
		}

		if (descriptive.equals("false")) {
			System.out.println("Opted for non descriptive results.");
			rn1.createCell(1).setCellValue("Pass");
			rn1.createCell(2).setCellValue("Pass");
		}
		FileOutputStream fos = new FileOutputStream(fileName);
		wb.write(fos);
		
		Assert.assertEquals("Alert configuration updated successfully for family.",login1.check());
		Thread.sleep(2000);
	}
	
	@AfterClass
	private void afterClass() throws IOException {
		driver.quit();
	}

}
