package com.cg.pages.locators.family.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Function;

import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.cg.base.testBase;
import com.cg.pages.constants.Common;
import com.cg.pages.locators.LoginPageLocators;
import com.cg.pages.locators.family.AddFamilyLocators;

public class AddFamilyLocatorsTest extends testBase {

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
		if (descriptive == null) {
			System.out.println("Enter the option you wish to continue");
			System.out.println("Press 1 for descriptive results");
			System.out.println("Press 2 for direct results");
			String answer;
			Scanner sc = new Scanner(System.in);
			answer = sc.nextLine();
			if (answer.equals("1")) {
				changeDescriptiveTrue();
			} else if (answer.equals("2")) {
				changeDescriptiveFalse();
			} else {
				System.out.println("Enter the correct option.");
				System.exit(0);
			}
		}
	}

	@org.testng.annotations.Test
	public void verifyLoginPage() throws InterruptedException, IOException {
		String fileName = prop.getProperty("excelurl");
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet ws = wb.createSheet(prop.getProperty("createSheetFamily"));
		XSSFRow rh = ws.createRow((short) 0);
		rh.createCell(0).setCellValue("Test Case Name");
		rh.createCell(1).setCellValue("Expected Result");
		rh.createCell(2).setCellValue("Actual Result");
		File file = new File(fileName);
		OutputStream fis = new FileOutputStream(file);

		XSSFRow rh1 = ws.createRow((short) 1);
		XSSFRow rh2 = ws.createRow((short) 2);
		XSSFRow rh3 = ws.createRow((short) 3);
		XSSFRow rh4 = ws.createRow((short) 4);
		XSSFRow rh5 = ws.createRow((short) 5);
		XSSFRow rh6 = ws.createRow((short) 6);
		XSSFRow rh7 = ws.createRow((short) 7);
		XSSFRow rh8 = ws.createRow((short) 8);
		XSSFRow rh9 = ws.createRow((short) 9);
		XSSFRow rh10 = ws.createRow((short) 10);
		XSSFRow rh11 = ws.createRow((short) 11);
		XSSFRow rh12 = ws.createRow((short) 12);
		XSSFRow rh13 = ws.createRow((short) 13);
		XSSFRow rh14 = ws.createRow((short) 14);

		rh1.createCell(0).setCellValue("Add Alert At Family");
		LoginPageLocators login = new LoginPageLocators(driver,by);
		login.getEmailInputBox().sendKeys(prop.getProperty("username"));
		login.getPasswordInputBox().sendKeys(prop.getProperty("password"));
		try {
			rh2.createCell(0).setCellValue("Log In");
			rh2.createCell(1).setCellValue("Pass");
			login.getLoginButton().click();
			if (descriptive.equals("true")) {
				rh2.createCell(2).setCellValue("Pass");
			}
		} catch (Exception e) {
			rh2.createCell(2).setCellValue("Fail");
		}

		Thread.sleep(3000);

		AddFamilyLocators login1 = new AddFamilyLocators(driver);

		Common newCommon = new Common(driver);
		
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				  .withTimeout(Duration.ofSeconds(30))
				  .pollingEvery(Duration.ofSeconds(5))
				  .ignoring(NoSuchElementException.class, TimeoutException.class).ignoring(StaleElementReferenceException.class);
		
		String colorValue = wait.until(new Function<WebDriver, String>() {
		     public String apply(WebDriver driver) {
		    	 WebElement shadowDomHostElementSite = driver.findElement(By.cssSelector(
		 				"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(3)"));
		 		WebElement lastSite = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot",
		 				shadowDomHostElementSite);
		 		WebElement siteDropdown = lastSite.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		 		System.out.println(ExpectedConditions.elementToBeClickable(siteDropdown));
		       if(ExpectedConditions.elementToBeClickable(siteDropdown) != null) {
		    	   System.out.println("In site drop down");
		    	   return "true";
		       }else {
		    	   throw new NoSuchElementException("User Defined Stale Element Exception");
		       }
		     }
		   });

		wait.until(ExpectedConditions.elementToBeClickable(newCommon.getSiteDropDown()));
		// Site start
		newCommon.getSiteDropDown().click();
		List<WebElement> SiteOptions = newCommon.getSiteDropDownList();
		WebElement siteOption = newCommon.checkList(SiteOptions, prop.getProperty("site01"));
		if (siteOption != null) {
			try {
				rh3.createCell(0).setCellValue("Site Name");
				rh3.createCell(1).setCellValue("Site Name is selected");
				siteOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Site Name is clicked");
					rh3.createCell(2).setCellValue("Site Name is selected");
				}
			} catch (Exception e) {
				System.out.println("Error in site name.");
				rh3.createCell(2).setCellValue("Fail");
			}
		} else {
			System.out.println("Error in site option.");
		}

		// Site end
		// Building start
		newCommon.getBuildingDropDown().click();
		List<WebElement> BuildingOptions = newCommon.getBuildingDropDownList();
		WebElement buildingOption = newCommon.checkList(BuildingOptions, prop.getProperty("building01S01"));
		if (buildingOption != null) {
			try {
				rh4.createCell(0).setCellValue("Building Name");
				rh4.createCell(1).setCellValue("Building Name is selected");
				buildingOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Building Name is clicked");
					rh4.createCell(2).setCellValue("Building Name is selected");
				}
			} catch (Exception e) {
				System.out.println("Error in Building name.");
				rh4.createCell(2).setCellValue("Error in Building name.");
			}
		} else {
			System.out.println("Error in building option.");
		}
		// Building end

		// tab
		List<WebElement> tab = new ArrayList<WebElement>();
		int i = 1;
		newCommon.selectTab(i);
		while (true) {
			try {
				WebElement tabNo = newCommon.selectTab(i);
				if (tabNo == null)
					break;
				tab.add(tabNo);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		boolean ans = false;
		for (int j = 0; j < tab.size(); j++) {

			if (tab.get(j).getText().equals(prop.getProperty("tabAlertConfiguration"))) {
				try {
					ans = true;
					rh5.createCell(0).setCellValue("Alert Configuration");
					rh5.createCell(1).setCellValue("Alert Configuration is selected");
					newCommon.selectTab(j + 1).click();
					if (descriptive.equals("true")) {
						System.out.println("Alert Configuration is clicked");
						rh5.createCell(2).setCellValue("Alert Configuration is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Alert Configuration.");
					rh5.createCell(2).setCellValue("Error in Alert Configuration");
				}

			} else {
				System.out.println("Error in Alert Configuration");
			}
		}
		// sub tab
		List<WebElement> subTab = new ArrayList<WebElement>();
		i = 1;
		newCommon.selectSubTab(i);
		while (true) {
			try {
				WebElement subTabNo = newCommon.selectSubTab(i);
				if (subTabNo == null)
					break;
				subTab.add(subTabNo);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		ans = false;
		for (int j = 0; j < subTab.size(); j++) {

			if (subTab.get(j).getText().equals(prop.getProperty("subtabAdd"))) {
				try {
					ans = true;
					rh6.createCell(0).setCellValue("Add");
					rh6.createCell(1).setCellValue("Add is selected");
					newCommon.selectSubTab(j + 1).click();
					if (descriptive.equals("true")) {
						System.out.println("Add is clicked");
						rh6.createCell(2).setCellValue("Add is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Add.");
					rh6.createCell(2).setCellValue("Error in Add");
				}
			} else {
				System.out.println("Error in Add");
			}

		}

		// Radio button
		WebElement radioButton = login1.familyRadioButton(prop.getProperty("radiobuttonFamily"));
		ans = false;
		try {
			ans = true;
			rh7.createCell(0).setCellValue("Family radio");
			rh7.createCell(1).setCellValue("Family radio is selected");
			radioButton.click();
			if (descriptive.equals("true")) {
				System.out.println("Family radio is clicked");
				rh7.createCell(2).setCellValue("Family radio is selected");
			}
		} catch (Exception e) {
			System.out.println("Error in Family radio");
			rh7.createCell(2).setCellValue("Error in Family radio");
		}
		// family
		List<WebElement> family = new ArrayList<WebElement>();
		i = 1;
		login1.familyDropDown().click();
		while (true) {
			try {
				WebElement familyValue = login1.familyDropDownValue(i);
				if (familyValue == null)
					break;
				family.add(familyValue);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		ans = false;
		for (int j = 0; j < family.size(); j++) {

			if (family.get(j).getText().equals(prop.getProperty("familynameFamily2"))) {
				try {
					ans = true;
					rh8.createCell(0).setCellValue("Family Value");
					rh8.createCell(1).setCellValue("Family Value is selected");
					login1.familyDropDownValue(j + 1).click();
					if (descriptive.equals("true")) {
						Thread.sleep(2000);
						System.out.println("Family Value is selected");
						rh8.createCell(2).setCellValue("Family Value is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Family Value");
					rh8.createCell(2).setCellValue("Error in Family Value");
				}
			}
		}
		List<WebElement> property = new ArrayList<WebElement>();
		i = 1;
		login1.propertyName().click();
		while (true) {
			try {
				WebElement propertyValue = login1.propertyNameValue(i);
				if (propertyValue == null)
					break;
				property.add(propertyValue);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		ans = false;
		for (int j = 0; j < property.size(); j++) {

			if (property.get(j).getText().equals(prop.getProperty("propertynameTemperature"))) {
				try {
					ans = true;
					rh9.createCell(0).setCellValue("Property Value");
					rh9.createCell(1).setCellValue("Property Value is selected");
					login1.propertyNameValue(j + 1).click();
					if (descriptive.equals("true")) {
						System.out.println("Property Value is selected");
						rh9.createCell(2).setCellValue("Property Value is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Property Value");
					rh9.createCell(2).setCellValue("Error in Property Value");
				}
			}
		}
		ans = false;
		try {
			ans = true;
			rh10.createCell(0).setCellValue("Alert Name");
			rh10.createCell(1).setCellValue("Alert Name is Vaild");
			login1.alertName().sendKeys(prop.getProperty("alertnameLowTempDemoAlert1"));
			if (descriptive.equals("true")) {
				System.out.println("Alert Name is Vaild");

				rh10.createCell(2).setCellValue("Alert Name is Vaild");
			}
		} catch (Exception e) {
			System.out.println("Error in Alert Name");
			rh10.createCell(2).setCellValue("Error in Alert Name");
		}

		try {
			rh11.createCell(0).setCellValue("Alert Type");
			rh11.createCell(1).setCellValue("Alert Type is selected");
			login1.alertType().click();
			if (descriptive.equals("true")) {
				System.out.println("Alert Type is selected");
				rh11.createCell(2).setCellValue("Alert Type is selected");
			}
		} catch (Exception e) {
			System.out.println("Error in Alert Type");
			rh11.createCell(2).setCellValue("Error in Alert Type");
		}
		try {
			rh12.createCell(0).setCellValue("Alert Value");
			rh12.createCell(1).setCellValue("Alert Value is valid");
			login1.alertValue().sendKeys(prop.getProperty("alertvalue"));
			if (descriptive.equals("true")) {
				System.out.println("Alert Value is valid");

				rh12.createCell(2).setCellValue("Alert Value is valid");
			}
		} catch (Exception e) {
			System.out.println("Error in Alert Value");
			rh12.createCell(2).setCellValue("Error in Alert Value");
		}

		try {
			rh13.createCell(0).setCellValue("Limit");
			rh13.createCell(1).setCellValue("Limit is selected");
			login1.limit().click();
			if (descriptive.equals("true")) {
				System.out.println("Limit is selected");
				rh13.createCell(2).setCellValue("Limit is selected");
			}
		} catch (Exception e) {
			System.out.println("Error in Limit");
			rh13.createCell(2).setCellValue("Error in Limit");
		}

		try {
			rh14.createCell(0).setCellValue("Add Button");
			rh14.createCell(1).setCellValue("Add Button is clicked");
			login1.add().click();
			if (descriptive.equals("true")) {
				System.out.println("Reached Family Alert Add Successfully.");
				rh14.createCell(2).setCellValue("Add Button is clicked");
			}
		} catch (Exception e) {
			System.out.println("Error in AddButton");
			rh14.createCell(2).setCellValue("Error in Add Button");
		}

		if (descriptive.equals("false")) {
			System.out.println("Opted for non descriptive results.");
			rh1.createCell(1).setCellValue("Pass");
			rh1.createCell(2).setCellValue("Pass");
		}
		FileOutputStream fos = new FileOutputStream(fileName);
		wb.write(fos);
		
		Assert.assertEquals("Alert Config successfully added for family.",login1.check());
		
		Thread.sleep(2000);
	}
	
	@AfterClass
	private void afterClass() throws IOException {
		driver.quit();
	}
}
