package com.cg.pages.locators.family.test;

import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;

import com.cg.base.testBase;
import com.cg.pages.constants.Common;
import com.cg.pages.locators.LoginPageLocators;
import com.cg.pages.locators.family.AddFamilyLocators;

import org.testng.Assert;

public class NewAddFamilyTest extends testBase {
	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void addAlertFamily() throws InterruptedException, IOException {

		Common newCommon = new Common(driver);
		AddFamilyLocators addFamily = new AddFamilyLocators(driver);
		LoginPageLocators login = new LoginPageLocators(driver, by);
		login.getEmailInputBox().sendKeys(prop.getProperty("username"));
		login.getPasswordInputBox().sendKeys(prop.getProperty("password"));

		login.getLoginButton().click();
		Thread.sleep(6000);

		// Site Drop down
		newCommon.getSiteDropDown().click();
		WebElement site = newCommon.getSiteDropDownListNew("Site01");
		site.click();

		// Building Drop down
		newCommon.getBuildingDropDown().click();
		WebElement building = newCommon.getBuildingDropDownListNew("Building01S01");
		building.click();

		// Tab
		WebElement tab = newCommon.getTabNew("Alert Configuration");
		tab.click();

		// Sub Tab
		WebElement subTab = newCommon.selectSubTabNew("Add");
		subTab.click();

		// Radio Button (Family / Measurement Point)
		newCommon.familyRadioButton("Family").click();

		// Family Name drop down
		newCommon.familyDropDown().click();
		WebElement familyValue = newCommon.familyDropDownListNew("Family2");
		familyValue.click();

		// Property Name drop down
		addFamily.propertyName().click();
		WebElement propertyName = newCommon.propertyNameDropDownListNew("Battery");
		propertyName.click();

		// Alert Name
		addFamily.alertName().sendKeys("LowTempDemoAlertOne");

		// Alert Type
		addFamily.alertType().click();

		// Alert Value
		addFamily.alertValue().sendKeys("20");

		// Alert Add Button
		addFamily.add().click();
		Thread.sleep(1000);

		boolean result = false;

		if (newCommon.statusMessage().equals("Alert Config successfully added for family.")) {
			result = true;
		}

		Assert.assertEquals("Alert Config successfully added for family.", newCommon.statusMessage());
	}
}
