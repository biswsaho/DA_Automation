package com.cg.pages.locators.torque;


import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;

import com.cg.base.testBase;
import com.cg.pages.constants.Common;
import com.cg.pages.locators.LoginPageLocators;

public class TorqueKeyLocatorsTest extends testBase {

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}

	@org.testng.annotations.Test
	public void TorqueTestCase() throws InterruptedException, IOException {
		LoginPageLocators login = new LoginPageLocators(driver);
		
		// Login
		login.getEmailInputBox().sendKeys("Admin");
		login.getPasswordInputBox().sendKeys("Capgemini@1234");
		login.getLoginButton().click();
		Thread.sleep(7000);
		
		// Creating objects
		Common newCommon= new Common(driver);
		TorqueKeyLocators torque = new TorqueKeyLocators(driver);
		
		// File upload
		torque.fileUpload().sendKeys("C:\\Users\\SAABHANG\\Downloads\\TEST5.csv");
		Thread.sleep(3000);
		torque.fileUploadButton().click();
		
		// Torque Key Drop down value
		torque.torqueKeyDropDown().click();
		List<WebElement> torqueKeyOptions = torque.torqueKeyDropDownList();
		WebElement torqueOption = newCommon.checkList(torqueKeyOptions, "Torque Key1");
		
		// Clicking the drop down value
		if (torqueOption != null) {
			try {
				torqueOption.click();
			}
			catch(Exception e) {
				System.out.println("Error in selecting torque dropdown value");
				System.exit(0);
			}
		}
		Thread.sleep(1000);
		
		// Click start button
		WebElement startButton = torque.startButton();
		startButton.click();
		
		// Scheduled jobs table
		List<String> tableRowsList = torque.getTableData();
		
		// Print Table data color
		for(String x: tableRowsList) {
			System.out.println(x);
		}
	}
}


