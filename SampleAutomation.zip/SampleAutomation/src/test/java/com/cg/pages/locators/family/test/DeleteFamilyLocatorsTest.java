package com.cg.pages.locators.family.test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.cg.base.testBase;
import com.cg.pages.constants.Common;
import com.cg.pages.locators.LoginPageLocators;
import com.cg.pages.locators.family.DeleteFamilyLocators;

public class DeleteFamilyLocatorsTest extends testBase {

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
		if (descriptive == null) {

			System.out.println("Enter the option you wish to continue");
			System.out.println("Press 1 for descriptive results");
			System.out.println("Press 2 for direct results");

			String answer;
			Scanner sc = new Scanner(System.in);
			answer = sc.nextLine();

			if (answer.equals("1")) {
				changeDescriptiveTrue();
			} else if (answer.equals("2")) {
				changeDescriptiveFalse();
			} else {
				System.out.println("Enter the correct option.");
				System.exit(0);
			}
		}
	}

	@org.testng.annotations.Test
	public void verifyLoginPage() throws InterruptedException, IOException {
		String fileName = prop.getProperty("excelurl");

		File file = new File(fileName);
		FileInputStream fis = new FileInputStream(file);

		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheet(prop.getProperty("createSheetFamily"));

		int rowCount = ws.getLastRowNum();
		int rowNo = rowCount+2;
		XSSFRow rn15 = ws.createRow((short) rowNo++);
		XSSFRow rn16 = ws.createRow((short) rowNo++);
		XSSFRow rn17 = ws.createRow((short) rowNo++);
		XSSFRow rn18 = ws.createRow((short) rowNo++);
		XSSFRow rn19 = ws.createRow((short) rowNo++);
		XSSFRow rn20 = ws.createRow((short) rowNo++);
		XSSFRow rn21 = ws.createRow((short) rowNo++);
		XSSFRow rn23 = ws.createRow((short) rowNo++);
		XSSFRow rn24 = ws.createRow((short) rowNo++);
		XSSFRow rn25 = ws.createRow((short) rowNo++);
		rn15.createCell(0).setCellValue("Delete Alert At Family");
		LoginPageLocators login = new LoginPageLocators(driver);
		login.getEmailInputBox().sendKeys(prop.getProperty("username"));
		login.getPasswordInputBox().sendKeys(prop.getProperty("password"));
		try {
			rn16.createCell(0).setCellValue("Log In");
			rn16.createCell(1).setCellValue("Pass");
			login.getLoginButton().click();
			if (descriptive.equals("true")) {
				rn16.createCell(2).setCellValue("Pass");
			}
		} catch (Exception e) {
			rn16.createCell(2).setCellValue("Fail");
		}

		DeleteFamilyLocators dele = new DeleteFamilyLocators(driver);
		Common newCommon = new Common(driver);
		Thread.sleep(4000);
		newCommon.getSiteDropDown().click();
		List<WebElement> SiteOptions = newCommon.getSiteDropDownList();

		WebElement siteOption = newCommon.checkList(SiteOptions, prop.getProperty("site01"));
		if (siteOption != null) {
			try {
				rn17.createCell(0).setCellValue("Site Name");
				rn17.createCell(1).setCellValue("Site Name is selected");
				siteOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Site Name is clicked");
					rn17.createCell(2).setCellValue("Site Name is selected");
				}
			} catch (Exception e) {
				System.out.println("Error in site name.");
				rn17.createCell(2).setCellValue("Fail");
				FileOutputStream fos = new FileOutputStream(fileName);
				wb.write(fos);
			}

		} else {
			System.out.println("Error in site option.");
		}

		// Site end

		// Building start
		newCommon.getBuildingDropDown().click();

		List<WebElement> BuildingOptions = newCommon.getBuildingDropDownList();

		WebElement buildingOption = newCommon.checkList(BuildingOptions, prop.getProperty("building01S01"));

		if (buildingOption != null) {
			try {
				rn18.createCell(0).setCellValue("Building Name");
				rn18.createCell(1).setCellValue("Building Name is selected");
				buildingOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Building Name is clicked");
					rn18.createCell(2).setCellValue("Building Name is selected");

				}
			} catch (Exception e) {
				System.out.println("Error in Building name.");
				rn18.createCell(2).setCellValue("Error in Building name.");

			}

		} else {
			System.out.println("Error in building option.");
		}
		// Building end
		// tab
		List<WebElement> tab = new ArrayList<WebElement>();
		int i = 1;
		newCommon.selectTab(i);
		while (true) {
			try {
				WebElement tabNo = newCommon.selectTab(i);
				if (tabNo == null)
					break;
				tab.add(tabNo);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		boolean ans = false;
		for (int j = 0; j < tab.size(); j++) {

			if (tab.get(j).getText().equals(prop.getProperty("tabAlertConfiguration"))) {
				try {
					ans = true;
					rn19.createCell(0).setCellValue("Alert Configuration");
					rn19.createCell(1).setCellValue("Alert Configuration is selected");
					newCommon.selectTab(j + 1).click();
					if (descriptive.equals("true")) {
						System.out.println("Alert Configuration is clicked");

						rn19.createCell(2).setCellValue("Alert Configuration is selected");

					}
				} catch (Exception e) {
					System.out.println("Error in Alert Configuration.");
					rn19.createCell(2).setCellValue("Error in Alert Configuration");
				}
				FileOutputStream fos = new FileOutputStream(fileName);
				wb.write(fos);

			} else {
				System.out.println("Error in Alert Configuration");
			}

		}
		List<WebElement> subTabOptions = newCommon.getSubTab();

		WebElement subTabValue = newCommon.checkList(subTabOptions, prop.getProperty("subtabDelete"));
		if (subTabValue != null) {
			try {
				rn20.createCell(0).setCellValue("Delete");
				rn20.createCell(1).setCellValue("Delete is selected");
				subTabValue.click();
				if (descriptive.equals("true")) {
					System.out.println("Delete is clicked");

					rn20.createCell(2).setCellValue("Delete");

				}
			} catch (Exception e) {
				System.out.println("Error in Delete.");
				rn20.createCell(2).setCellValue("Error in Delete");
			}
		}

		WebElement radioButton = dele.familyRadioButton(prop.getProperty("radiobuttonFamily"));
		ans = false;
		try {
			ans = true;
			rn21.createCell(0).setCellValue("Family radio");
			rn21.createCell(1).setCellValue("Family radio is selected");
			radioButton.click();
			if (descriptive.equals("true")) {
				System.out.println("Family radio is clicked");

				rn21.createCell(2).setCellValue("Family radio is selected");

			}
		} catch (Exception e) {
			System.out.println("Error in Family radio");
			rn21.createCell(2).setCellValue("Error in Family radio");
		}

		// family
		List<WebElement> family = new ArrayList<WebElement>();
		i = 1;
		dele.FamilyDropdown().click();
		while (true) {
			try {
				WebElement familyValue = dele.FamilyDropDownValue(i);
				if (familyValue == null)
					break;
				family.add(familyValue);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		ans = false;
		for (int j = 0; j < family.size(); j++) {

			if (family.get(j).getText().equals(prop.getProperty("familynameFamily2"))) {
					dele.FamilyDropDownValue(j + 1).click();
			}
		}
		List<WebElement> property = new ArrayList<WebElement>();
		i = 1;
		dele.PropertyName().click();
		while (true) {
			try {
				WebElement propertyValue = dele.propertyNameValue(i);
				if (propertyValue == null)
					break;
				property.add(propertyValue);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		ans = false;
		for (int j = 0; j < property.size(); j++) {

			if (property.get(j).getText().equals(prop.getProperty("propertynameTemperature"))) {
				try {
					ans = true;
					rn23.createCell(0).setCellValue("Property Value");
					rn23.createCell(1).setCellValue("Property Value is selected");
					dele.propertyNameValue(j + 1).click();

					if (descriptive.equals("true")) {
						System.out.println("Property Value is selected");

						rn23.createCell(2).setCellValue("Property Value is selected");
					}
				} catch (Exception e) {
					System.out.println("Error in Property Value");
					rn23.createCell(2).setCellValue("Error in Property Value");
				}
			}
		}
		
		try {
			dele.Grid().click();
			rn24.createCell(0).setCellValue("Delete Button");
			rn24.createCell(1).setCellValue("Delete Button is clicked");
			dele.DeleteButton().click();
			if (descriptive.equals("true")) {
				System.out.println("Reached Family Alert Delete Successfully.");

				rn24.createCell(2).setCellValue("Delete Button is clicked");
			}
		} catch (Exception e) {
			System.out.println("Error in DeleteButton");
			rn24.createCell(2).setCellValue("Error in Delete Button");
		}

		if (descriptive.equals("false")) {
			System.out.println("Opted for non descriptive results.");
			rn15.createCell(1).setCellValue("Pass");
			rn15.createCell(2).setCellValue("Pass");
		}
		FileOutputStream fos = new FileOutputStream(fileName);
		wb.write(fos);
		try {
			rn25.createCell(0).setCellValue("Delete Test Result");
			rn25.createCell(1).setCellValue("Delete Test Successful");
			if(dele.check().equals("Successfully deleted alert configuration for measurement family.")) {
				rn25.createCell(2).setCellValue("Delete Test Successful");
			}else {
				throw new Exception();
			}
		} catch (Exception e) {
			// TODO: handle exception
			rn25.createCell(2).setCellValue("Error in Delete Test Case");
		}
		Assert.assertEquals("Successfully deleted alert configuration for measurement family.",dele.check());
		Thread.sleep(2000);
	}
	
	@AfterClass
	private void afterClass() throws IOException {
		driver.quit();
	}
}
