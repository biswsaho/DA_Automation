package com.cg.pages.locators.family.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.cg.base.testBase;
import com.cg.pages.constants.Common;
import com.cg.pages.locators.LoginPageLocators;
import com.cg.pages.locators.family.NewMeasurementPointLocator;

public class NewMeasurementPointTest extends testBase {

	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
		if (descriptive == null) {
			System.out.println("Enter the option you wish to continue");
			System.out.println("Press 1 for descriptive results");
			System.out.println("Press 2 for direct results");

			String answer;
			Scanner sc = new Scanner(System.in);
			answer = sc.nextLine();

			if (answer.equals("1")) {
				changeDescriptiveTrue();
			} else if (answer.equals("2")) {
				changeDescriptiveFalse();
			} else {
				System.out.println("Enter the correct option.");
				System.exit(0);
			}
		}
	}
	

	@org.testng.annotations.Test
	public void verifyLoginPage() throws InterruptedException, IOException {
	
	 String fileName = prop.getProperty("excelurl");

			File file = new File(fileName);
			FileInputStream fis = new FileInputStream(file);

			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet ws = wb.getSheet(prop.getProperty("createSheetFamily"));

			int rowCount = ws.getLastRowNum();
			int rowNo = rowCount+2;
			XSSFRow rn25 = ws.createRow((short) rowNo++);
			XSSFRow rn26 = ws.createRow((short) rowNo++);
			XSSFRow rn27 = ws.createRow((short) rowNo++);
			XSSFRow rn28 = ws.createRow((short) rowNo++);
			XSSFRow rn29 = ws.createRow((short) rowNo++);
			XSSFRow rn30 = ws.createRow((short) rowNo++);
			XSSFRow rn31 = ws.createRow((short) rowNo++);
			XSSFRow rn32 = ws.createRow((short) rowNo++);
			XSSFRow rn33 = ws.createRow((short) rowNo++);
			XSSFRow rn34 = ws.createRow((short) rowNo++);
			

			rn25.createCell(0).setCellValue("Adding New Measurement Point");
		// Dependencies
		LoginPageLocators login = new LoginPageLocators(driver);
		Common newCommon= new Common(driver);
		NewMeasurementPointLocator addMeasurementLocator = new NewMeasurementPointLocator(driver);
		
		// Login
		login.getEmailInputBox().sendKeys(prop.getProperty("username"));
		login.getPasswordInputBox().sendKeys(prop.getProperty("password"));
		
		try {
			rn26.createCell(0).setCellValue("Log In");
			rn26.createCell(1).setCellValue("Pass");
			login.getLoginButton().click();
			if (descriptive.equals("true")) {
				rn26.createCell(2).setCellValue("Pass");
				FileOutputStream fos = new FileOutputStream(fileName);
				wb.write(fos);
			}
		} catch (Exception e) {
			rn26.createCell(2).setCellValue("Fail");
			FileOutputStream fos = new FileOutputStream(fileName);
			wb.write(fos);
		}
		
		 // Site Drop down
		Thread.sleep(4000);
		WebElement siteDropdown = newCommon.getSiteDropDown(); 
		siteDropdown.click();
		Thread.sleep(2000);
		List<WebElement> SiteOptions = newCommon.getSiteDropDownList();
		Thread.sleep(2000);
		WebElement siteOption = newCommon.checkList(SiteOptions, prop.getProperty("site01"));
		  
		if(siteOption != null) {
			try {
				rn27.createCell(0).setCellValue("Site Name");
				rn27.createCell(1).setCellValue("Site Name is selected");
				siteOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Site Name is clicked");
					
					rn27.createCell(2).setCellValue("Site Name is selected");
					FileOutputStream fos = new FileOutputStream(fileName);
					wb.write(fos);

				}
			} catch (Exception e) {
				System.out.println("Error in site name.");
				rn27.createCell(2).setCellValue("Fail");
			}
		}else {
			System.out.println("Error in site option.");
			System.exit(0);
		}
		
		// Building
		newCommon.getBuildingDropDown().click();
		
		List<WebElement> BuildingOptions = newCommon.getBuildingDropDownList();
		
		WebElement buildingOption = newCommon.checkList(BuildingOptions, prop.getProperty("building01S01"));
		
		if(buildingOption.getSize() != null) {
			try {
				rn28.createCell(0).setCellValue("Building Name");
				rn28.createCell(1).setCellValue("Building Name is selected");
				buildingOption.click();
				if (descriptive.equals("true")) {
					System.out.println("Building Name is clicked");
					
					rn28.createCell(2).setCellValue("Building Name is selected");

				}
			} catch (Exception e) {
				System.out.println("Error in Building name.");
				rn28.createCell(2).setCellValue("Error in Building name.");
			}
		}else {
			System.out.println("Error in building option.");
		}
		
		// Tab
		List<WebElement> tabOptions = newCommon.getTab();
		
		WebElement tabValue = newCommon.checkList(tabOptions, prop.getProperty("tabAddandDelete"));
		
		if(tabValue != null) {
			try {
				rn29.createCell(0).setCellValue("Add/Delete Measurement Point");
				rn29.createCell(1).setCellValue("Add/Delete Measurement Point is selected");
				tabValue.click();
				if (descriptive.equals("true")) {
					System.out.println("Add/Delete Measurement Point is clicked");
					
					rn29.createCell(2).setCellValue("Add/Delete Measurement Point is selected");

				}
			} catch (Exception e) {
				System.out.println("Error in Add/Delete Measurement Point.");
				rn29.createCell(2).setCellValue("Error in Add/Delete Measurement Point");
			}
		}else {
			System.out.println("Error in Tab option.");
		}
		
		// Stream drop down
		WebElement streamDropdown = addMeasurementLocator.streamDropDown();
		streamDropdown.click();
		
		List<WebElement> streamList = addMeasurementLocator.streamDropDownValueList();
		
		WebElement streamValue = newCommon.checkList(streamList, prop.getProperty("streamValue"));
		
		if(streamValue != null) {
			try {
				rn30.createCell(0).setCellValue("Stream Value");
				rn30.createCell(1).setCellValue("Stream Value is selected");
				streamValue.click();
			if (descriptive.equals("true")) {
				System.out.println("Stream Value is Selected");
				rn30.createCell(2).setCellValue("Stream Value is selected");

			}
		} catch (Exception e) {
			System.out.println("Error in Stream Value.");
			rn30.createCell(2).setCellValue("Error in Stream Value");
		}
		}else {
			System.out.println("Error in stream option.");
		}
		
		// Family drop down
		addMeasurementLocator.familyDropDown().click();
		
		List<WebElement> familyList = addMeasurementLocator.familyDropDownValueList();
		
		WebElement familyValue = newCommon.checkList(familyList,prop.getProperty("familynameFamily2"));
		
		if(familyValue != null) {
			try {
				rn31.createCell(0).setCellValue("Family Value");
				rn31.createCell(1).setCellValue("Family Value is selected");
				familyValue.click();
			if (descriptive.equals("true")) {
				System.out.println("Family Value is Selected");
				rn31.createCell(2).setCellValue("Family Value is selected");

			}
		} catch (Exception e) {
			System.out.println("Error in Family Value.");
			rn31.createCell(2).setCellValue("Error in Family Value");
		}
			
		}else {
			System.out.println("Error in family option.");
		}
		
		// Measurement name
		try {
			rn32.createCell(0).setCellValue("Measurement Value");
			rn32.createCell(1).setCellValue("Measurement Value is selected");
		addMeasurementLocator.measurementPointName(prop.getProperty("measurementValue"));
		if (descriptive.equals("true")) {
			System.out.println("Measurememt Value is selected");
			
			rn32.createCell(2).setCellValue("Measurement Value is selected");
		}
	} catch (Exception e) {
		System.out.println("Error in Measurememt Value");
		rn32.createCell(2).setCellValue("Error in Measurememt Value");
	}

		try {
			rn33.createCell(0).setCellValue("Measurement Point");
			rn33.createCell(1).setCellValue("Measurement Point Added Successfully");
		addMeasurementLocator.addButton().click();
		if (descriptive.equals("true")) {
			System.out.println("Measurement Point Added Successfully.");
			rn33.createCell(0).setCellValue("Measurement Point");
			rn33.createCell(1).setCellValue("Measurement Point Added Successfully");
			rn33.createCell(2).setCellValue("Measurement Point Added Successfully");
		}
	} catch (Exception e) {
		System.out.println("Error in adding measurement point");
		rn33.createCell(2).setCellValue("Error in adding measurement point");
	}
	
		Thread.sleep(1000);
		String successText = "New Measurement Point has been added.";
		
		boolean measurementPointAdded = true;
		try {
			rn34.createCell(0).setCellValue("Measurement Point Result");
			rn34.createCell(1).setCellValue("Measurement Point with this name is already present");
		if(successText.equals(addMeasurementLocator.successText().getText())) {
			
			measurementPointAdded = false;
			if (descriptive.equals("true")) {
				
				rn34.createCell(2).setCellValue("New Measurement Point has been added");
			}
		}
		}catch(Exception e) {
			rn34.createCell(2).setCellValue("New Measurement Point is not added");
		}
		
		System.out.println(addMeasurementLocator.successText().getText());
		
		FileOutputStream fos = new FileOutputStream(fileName);
		wb.write(fos);
		Assert.assertTrue("MP point is already present", measurementPointAdded);
		if (descriptive.equals("false")) {
			System.out.println("Opted for non descriptive results.");
			rn26.createCell(0).setCellValue("Measurement Point");
			rn26.createCell(1).setCellValue("Pass");
			rn26.createCell(2).setCellValue("Pass");
			
		}
		FileOutputStream fos1 = new FileOutputStream(fileName);
		wb.write(fos1);
		Thread.sleep(2000);
		}
	
		@AfterClass
		private void afterClass() throws IOException {
			driver.quit();
		}
}
