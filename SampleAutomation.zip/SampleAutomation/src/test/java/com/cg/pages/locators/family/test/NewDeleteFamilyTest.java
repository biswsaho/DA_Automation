	package com.cg.pages.locators.family.test;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.cg.base.testBase;
import com.cg.pages.constants.Common;
import com.cg.pages.locators.LoginPageLocators;
import com.cg.pages.locators.family.AddFamilyLocators;
import com.cg.pages.locators.family.DeleteFamilyLocators;

public class NewDeleteFamilyTest extends testBase {
	@BeforeClass
	private void beforeClass() throws IOException {
		initialization();
	}
	
	@org.testng.annotations.Test
	public void deleteAlertFamily() throws InterruptedException, IOException {

		Common newCommon = new Common(driver);
		AddFamilyLocators addFamily = new AddFamilyLocators(driver);
		LoginPageLocators login = new LoginPageLocators(driver,by);
		DeleteFamilyLocators deleteFamilyLocator = new DeleteFamilyLocators(driver);
	
		
		login.getEmailInputBox().sendKeys(prop.getProperty("username"));
		login.getPasswordInputBox().sendKeys(prop.getProperty("password"));
		
	    login.getLoginButton().click();
	    Thread.sleep(6000);

	    // Site Drop down
	    newCommon.getSiteDropDown().click();
	    WebElement site = newCommon.getSiteDropDownListNew("Site01");
	    site.click();

	    // Building Drop down
	    newCommon.getBuildingDropDown().click();
	    WebElement building = newCommon.getBuildingDropDownListNew("Building01S01");
	    building.click();
	    
	    // Tab
	    WebElement tab = newCommon.getTabNew("Alert Configuration");
	    tab.click();
	    
	    // Sub Tab
	    WebElement subTab = newCommon.selectSubTabNew("Delete");
	    subTab.click();
	    
	    // Radio Button (Family / Measurement Point)
	    WebElement radio = deleteFamilyLocator.familyRadioButton("Family");
	    radio.click();
	    
	    // Family Name drop down
	    deleteFamilyLocator.FamilyDropdown().click();
	    WebElement familyValue = newCommon.deleteFamilyDropDownListNew("Family2");
	    familyValue.click();
	    
	    // Property Name drop down
	    deleteFamilyLocator.PropertyName().click();
	    WebElement propertyName = newCommon.deletePropertyNameDropDownListNew("Battery");
	    propertyName.click();
	    	    
	    // Select Element from table
	    WebElement deleteElement = newCommon.deleteTableElement("LowTempDemoAlertOne");
	    deleteElement.click();
	    // Delete Button
	    deleteFamilyLocator.DeleteButton().click();
	    
	    boolean result = false;
	    
	    if(deleteFamilyLocator.check().equals("Successfully deleted alert configuration for measurement family.")) {
	    	result = true;
	    }
	    
//	    assertEquals(true, result);
	    
	    Assert.assertEquals("Successfully deleted alert configuration for measurement family.",deleteFamilyLocator.check());
	}
}