package com.cg.base;

import java.io.File;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class testBase {

	public static Properties prop;
	public static Properties testProp;
	public static WebDriver driver;
	public static String descriptive;
	public static By by;

	public testBase() {
		try {
			prop=new Properties();
			FileInputStream fs = new FileInputStream("C:\\Users\\shtaleka\\SampleAutomation\\src\\main\\java\\com\\cg\\defaultProperties\\PropertiesValue");
			prop.load(fs);
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void changeDescriptiveTrue() {
		descriptive = "true";
	}
	
	public static void changeDescriptiveFalse() {
		descriptive = "false";
	}

 	@SuppressWarnings("deprecation")
	public static void initialization() {
		new testBase();
		String browser=prop.getProperty("browser");

		// Launch the browser
		if(browser.contains("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\shtaleka\\\\SampleAutomation\\\\Drivers\\\\ChromeDriver\\\\chromedriver.exe");
	        driver = new ChromeDriver();
		}else if(browser.contains("ff")) {
			WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();	
		}

		// Maximize the window
		driver.manage().window().maximize();
		
		// Delete all cookies
		driver.manage().deleteAllCookies();

		// Open the URL
		driver.get(prop.getProperty("url"));

		//driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
		//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
}
