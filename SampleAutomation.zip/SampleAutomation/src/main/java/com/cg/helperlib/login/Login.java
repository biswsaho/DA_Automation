package com.cg.helperlib.login;

import org.openqa.selenium.WebDriver;

import com.cg.pages.locators.LoginPageLocators;



public class Login {

	WebDriver driver;
	LoginPageLocators login= new LoginPageLocators(driver);

	/** Method to enter user-name in user-name text-box
	 * 
	 * @param userName Text for the user-name
	 * @return WebElement  
	 * @throws InterruptedException 
	 */
	public final void enterUserName(String userName) throws InterruptedException {
		Thread.sleep(1000);
		login.getEmailInputBox().click();
		////////////////////////////////////////////////////////////// I will have to add wait over here
		Thread.sleep(2000);
		login.getEmailInputBox().sendKeys(userName); 
		///////////////////////////////////////////////////////////////////	// I will have to add wait here		
	}

	/** Method to enter password in password text-box
	 * 
	 * @param password Text for the password
	 * @return WebElement  
	 * @throws InterruptedException 
	 */
	public final void enterPassword(String password) throws InterruptedException {
		Thread.sleep(1000);
		login.getPasswordInputBox().click();
		// I will have to add wait over here
		Thread.sleep(2000);
		login.getPasswordInputBox().sendKeys(password);
		// I will have to add wait here
	}

	/** Method to enter user-name and password and click on login button
	 * 
	 * @param userName Text for the user-name
	 * @param password Text for the password
	 * @return WebElement  
	 * @throws InterruptedException 
	 */
	public final void enterCredentialsAndClickOnLogin(String userName,String password) throws InterruptedException {
		// Enter user-name
		enterUserName(userName);
		// Enter password
		enterPassword(password);
		// Click on login button;
		/////////////////////////////////////////////////////// I will have to add wait here 
		login.getLoginButton().click();
	}

}
