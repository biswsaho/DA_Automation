package com.cg.pages.locators.family;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DeleteFamilyLocators {
	WebDriver driver;

	public DeleteFamilyLocators(WebDriver driver) {
		this.driver = driver;
	}
	// ----------------------------------------------------------- ALL LOCATOR
	// OBJECTS USING
	// XPATH------------------------------------------------------------------

	public WebElement familyRadioButton(String value) {
		WebElement Family = driver.findElement(By.xpath(
				"//*[@id=\"root_mashupcontainer-5_radiobuttonlist-288\"]/table/tbody/tr/td[1]"));
		WebElement MeasurementPoint = driver.findElement(By.xpath(
				"//*[@id=\"root_mashupcontainer-5_radiobuttonlist-288\"]/table/tbody/tr/td[2]"));
		
		if (value.equals("Family")) {
			return Family;
		}
		return MeasurementPoint;
	}

	public final WebElement FamilyDropdown() throws InterruptedException {

		// Family Dropdown
		String cssSelectorForHostFamilyDropDown = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(1)";
		WebElement shadowDomHostElementFamilyDropDown = driver.findElement(By.cssSelector(
				"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(1)"));
		WebElement lastFamilyDropDown = (WebElement) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDown);

		WebElement family = lastFamilyDropDown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return family;
	}

	public final WebElement FamilyDropDownValue(int i) throws InterruptedException {
		try {
			String cssSelectorForHostFamilyDropDownValue = "body > ptcs-list:nth-child(36)";
			Thread.sleep(1000);
			WebElement shadowDomHostElementFamilyDropDownValue = driver
					.findElement(By.cssSelector("body > ptcs-list:nth-child(36)"));
			WebElement lastFamilyDropDownValue = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDownValue);
			Thread.sleep(1000);
			lastFamilyDropDownValue.findElement(By.cssSelector(
					"div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child(3) > div:nth-child(1)"))
					.click();

			WebElement familyValue = lastFamilyDropDownValue.findElement(By.cssSelector(
					"div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("
							+ i + ") > div:nth-child(1)"));
			return familyValue;

		} catch (Exception e) {
			return null;
		}
	}

	public final WebElement PropertyName() throws InterruptedException {
		// Property Name
		Thread.sleep(100);
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(6) > ptcs-dropdown:nth-child(1)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		Thread.sleep(100);
		WebElement propertyName = last.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
		return propertyName;
	}

	public final WebElement propertyNameValue(int i) throws InterruptedException {
		try {
			// Property Name Value
			String cssSelectorForHostPropertyNameValue = "body > ptcs-list:nth-child(37)";
			WebElement shadowDomHostElementPropertyNameValue = driver
					.findElement(By.cssSelector("body > ptcs-list:nth-child(37)"));
			WebElement lastPropertyNameValue = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElementPropertyNameValue);
			WebElement propertyNameValue = lastPropertyNameValue.findElement(By.cssSelector(
					"div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("
							+ i + ") > div:nth-child(1)"));
			return propertyNameValue;
		} catch (Exception e) {
			return null;
		}
	}

	public final WebElement Grid() {
		// Delete Value
		return driver.findElement(By.xpath(
				"//body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[2]/div[1]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[3]/div[1]/div[1]/div[10]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[2]/td[1]"));
	}

	public final WebElement DeleteButton() {// Delete Button Click
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-304"));
	}
	
	public String check() throws InterruptedException {
        Thread.sleep(1000);
        String status=driver.findElement(By.xpath("//div[@id='status-msg-text']")).getText();
        return status;
    }
}
