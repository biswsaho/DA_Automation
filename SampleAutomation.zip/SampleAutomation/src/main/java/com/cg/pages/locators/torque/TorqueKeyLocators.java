package com.cg.pages.locators.torque;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class TorqueKeyLocators{
	WebDriver driver;
	
	public TorqueKeyLocators(WebDriver driver) {
		this.driver=driver;
}
	// ----------------------------------------------------------- ALL LOCATOR OBJECTS USING XPATH------------------------------------------------------------------
	
	// Choosing file
	public WebElement fileUpload() {
		return driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/form[1]/div[2]/input[1]"));
	}
	
	// Upload Button
	public WebElement fileUploadButton() {
		return driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/form[1]/div[2]/input[2]"));
	}
	
	// start button
	public WebElement startButton() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-37"));
	}
	
	// Torque Key Drop down start
	// Access Drop down
	public WebElement torqueKeyDropDown() throws InterruptedException {
		WebElement shadowDomHostElementTorqueKey = driver.findElement(By.cssSelector(".ptcs-wrapper.widget-content.widget-ptcsdropdown"));
        WebElement lastTorqueKey = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementTorqueKey);
        WebElement torque =lastTorqueKey.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
        return torque;
	}
	
	// Drop down value
	public WebElement torqueKeyDropDownvalue(int i) throws InterruptedException {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("ptcs-list[part='list']"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		return last.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("+ i +") > div:nth-child(1)"));
	}
	
	// Drop down list
	public List<WebElement> torqueKeyDropDownList(){
		  List<WebElement> torqueKeyOptions = new ArrayList<WebElement>();
		  int i = 1;
		  
		  while(true) { 
			  try { 
			  WebElement torqueKeyValue = torqueKeyDropDownvalue(i);
			  if(torqueKeyValue==null)
				  break;
			  torqueKeyOptions.add(torqueKeyValue); 
			  i++;
			  }
		  catch (Exception e) { 
			  break; 
			  } 
		  }
		return torqueKeyOptions;
	}
	
	// Scheduled Jobs Table start
	// All Table Rows
	public List<WebElement> tableRows() {
		List<WebElement> tableOptions = driver.findElements(By.xpath("//div[@id='root_mashupcontainer-5_gridadvanced-30-grid-advanced']//div[@class='objbox']//table//tr"));
		return tableOptions;
	}
	
	// Get Single Row
	public WebElement getOneRow(int i) {
		return driver.findElement(By.xpath("//div[@id='root_mashupcontainer-5_gridadvanced-30-grid-advanced']//div[@class='objbox']//table//tr["+ i +"]//td[10]"));
	}
	
	// List of colors
	public List<String> getTableData(){
		List<WebElement> tableOptions = tableRows();
		
		List<String> finalTableOptions = new ArrayList<String>();
		int size = tableOptions.size();
		
		int i = 2;
		while(i <= size) {
			  Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
						  .withTimeout(Duration.ofSeconds(30))
						  .pollingEvery(Duration.ofSeconds(5))
						  .ignoring(NoSuchElementException.class, TimeoutException.class).ignoring(StaleElementReferenceException.class);
			
		  	  final int tempVal = i;
			  String colorValue = wait.until(new Function<WebDriver, String>() {
				     public String apply(WebDriver driver) {
				       WebElement temp = getOneRow(tempVal);
				       if(temp.getText().equals("NOT-OK") || temp.getText().equals("OK")) {
				    	   return temp.getCssValue("background-color");
				       }else {
				    	   throw new NoSuchElementException("User Defined Stale Element Exception");
				       }
				     }
				   });
			  
			  finalTableOptions.add(colorValue);
			  i++;
		}
		
		return finalTableOptions;
	}

	// Scheduled Jobs Table end 
	
	public WebElement clearButton() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-37"));
	}
	
	public WebElement startDate() throws InterruptedException {
          String cssSelectorForHostStartDateTextbox = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(5) > div:nth-child(1) > div:nth-child(2) > ptcs-datepicker:nth-child(3)";
          String cssSelectorForHostStartDateTextbox1 = "ptcs-textfield[icon='page:calendar']";
          Thread.sleep(1000);
          WebElement shadowDomHostElementStartDateTextbox = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(5) > div:nth-child(1) > div:nth-child(2) > ptcs-datepicker:nth-child(3)"));
          WebElement lastStartDateTextbox = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementStartDateTextbox);
          Thread.sleep(1000);
          WebElement shadowDomHostElementStartDateTextbox1 = lastStartDateTextbox.findElement(By.cssSelector("ptcs-textfield[icon='page:calendar']"));
          WebElement lastStartDateTextbox1 = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementStartDateTextbox1);
          Thread.sleep(1000);
          WebElement start= lastStartDateTextbox1.findElement(By.cssSelector("div[part='text-box']"));
          return start;
	}
	public WebElement startDateValue() throws InterruptedException {
		String cssSelectorForHostStartDate = "ptcs-datepicker-calendar[part='calendar']";
        Thread.sleep(1000);
        WebElement shadowDomHostElementStartDate = driver.findElement(By.cssSelector("ptcs-datepicker-calendar[part='calendar']"));
        WebElement lastStartDate = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementStartDate);
        Thread.sleep(1000);
        WebElement startValue=lastStartDate.findElement(By.cssSelector("div:nth-child(2) > div:nth-child(4) > div:nth-child(17)"));
        return startValue;
	}
	public WebElement startButton1() throws InterruptedException {
		Thread.sleep(1000);
        WebElement shadowDomHostElementButton  = driver.findElement(By.cssSelector("ptcs-datepicker-calendar[part='calendar']"));
        WebElement lastButton  = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementButton );
        Thread.sleep(1000);
        WebElement start= lastButton .findElement(By.cssSelector("ptcs-button[variant='primary']"));
        return start;
	}
	public WebElement endDate() throws InterruptedException {
		String cssSelectorForHostEndDateTextBox = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(5) > div:nth-child(1) > div:nth-child(3) > ptcs-datepicker:nth-child(3)";
        String cssSelectorForHostEndDateTextBox1 = "ptcs-textfield[icon='page:calendar']";
        Thread.sleep(1000);
        WebElement shadowDomHostElementEndDateTextBox = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(5) > div:nth-child(1) > div:nth-child(3) > ptcs-datepicker:nth-child(3)"));
        WebElement lastEndDateTextBox = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementEndDateTextBox);
        Thread.sleep(1000);
        WebElement shadowDomHostElementEndDateTextBox1 = lastEndDateTextBox.findElement(By.cssSelector("ptcs-textfield[icon='page:calendar']"));
        WebElement lastEndDateTextBox1 = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementEndDateTextBox1);
        Thread.sleep(1000);
        WebElement end= lastEndDateTextBox1.findElement(By.cssSelector("div[part='text-box']"));
        return end;
	}
	public WebElement endDateValue() throws InterruptedException {
		String cssSelectorForHostEndDate = "body > ptcs-datepicker-calendar:nth-child(37)";
        Thread.sleep(1000);
        WebElement shadowDomHostElementEndDate = driver.findElement(By.cssSelector("body > ptcs-datepicker-calendar:nth-child(37)"));
        WebElement lastEndDate = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementEndDate);
        Thread.sleep(1000);
        WebElement endDateValue= lastEndDate.findElement(By.cssSelector("div:nth-child(2) > div:nth-child(4) > div:nth-child(17)"));
       return endDateValue;
	}
	public WebElement endButton() throws InterruptedException {
		String cssSelectorForHostButton1 = "body > ptcs-datepicker-calendar:nth-child(37)";
        Thread.sleep(1000);
        WebElement shadowDomHostElementButton1 = driver.findElement(By.cssSelector("body > ptcs-datepicker-calendar:nth-child(37)"));
        WebElement lastButton1 = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementButton1);
        Thread.sleep(1000);
        WebElement endButton= lastButton1.findElement(By.cssSelector("ptcs-button[variant='primary']"));
        return endButton;
	}
	public WebElement listSelection() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-76"));
	}
}
