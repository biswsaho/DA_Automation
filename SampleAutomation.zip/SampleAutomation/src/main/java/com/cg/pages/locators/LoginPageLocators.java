package com.cg.pages.locators;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

public class LoginPageLocators {

	WebDriver driver;
	WebElement we;
	By by;

	public LoginPageLocators(WebDriver driver, By by) {
		this.driver = driver;
		this.by = by;
		this.we = null;
	}

	
	// ----------------------------------------------------------- ALL LOCATOR
	// OBJECTS USING XPATH
	// ------------------------------------------------------------------

	// By userNameInputBox =
	// By.xpath("/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[1]/div/div[1]/div/div[1]/input");
	By userNameInputBox = By.xpath("/html/body/div/div[4]/form/input[1]");

	By passwordInputBox = By.xpath("/html/body/div/div[4]/form/input[2]");

	By loginButton = By.xpath("/html/body/div/div[4]/form/input[3]");

	By loginError = By.xpath("/html/body/div/div[4]/form/p");

	// ------------------------------------------------------------ ALL LOCATOR
	// LISTENER METHOD
	// ---------------------------------------------------------------------------

	/**
	 * Method to locate emailId input box
	 * 
	 * @return WebElement
	 */
	public final WebElement getEmailInputBox() {
		return driver.findElement(userNameInputBox);
	}

	/**
	 * Method to locate password input box
	 * 
	 * @return WebElement
	 */
	public final WebElement getPasswordInputBox() {
		return driver.findElement(passwordInputBox);
	}

	/**
	 * Method to locate login button
	 * 
	 * @return WebElement
	 */
	public final WebElement getLoginButton() {
		return driver.findElement(loginButton);
	}

	// Error Element
	public final WebElement errorElement() {
		return driver.findElement(loginError);
	}

}