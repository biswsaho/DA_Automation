package com.cg.pages.locators.family;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddFamilyLocators {
	WebDriver driver;
	
	public AddFamilyLocators(WebDriver driver) {
		this.driver=driver;
}
	// ----------------------------------------------------------- ALL LOCATOR OBJECTS USING XPATH------------------------------------------------------------------

	public WebElement familyRadioButton(String value) {
		 WebElement Family = driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[2]/div[1]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[1]/div[1]/div[1]/div[1]/div[3]/table[1]/tbody[1]/tr[1]/td[1]"));
		 WebElement MeasurementPoint = driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[2]/div[1]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[1]/div[1]/div[1]/div[1]/div[3]/table[1]/tbody[1]/tr[1]/td[2]"));
	     
		 if(value.equals("Family")) {
			 return Family;
		 }
	     
		 return MeasurementPoint;
	}
	
	public final WebElement familyDropDown() throws InterruptedException {
		// Family Dropdown
				String cssSelectorForHostFamilyDropDown = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(1)";
				WebElement shadowDomHostElementFamilyDropDown = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(1)"));
				WebElement lastFamilyDropDown = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDown);
				WebElement family=lastFamilyDropDown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
				return family;
	}
	
	public final WebElement familyDropDownValue(int i) throws InterruptedException {
		// Family Dropdown Value
		try {
				String cssSelectorForHostFamilyDropDownValue = "body > ptcs-list:nth-child(30)";
				WebElement shadowDomHostElementFamilyDropDownValue = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(30)"));
				WebElement lastFamilyDropDownValue = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDownValue);
				WebElement familyValue=lastFamilyDropDownValue.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("+i+") > div:nth-child(1)"));
				return familyValue;
		} catch (Exception e) {
			return null;
		}
	}
	public final WebElement propertyName() throws InterruptedException {
		// Property Name
				String cssSelectorForHostPropertyName = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(6) > ptcs-dropdown:nth-child(1)";
				WebElement shadowDomHostElementPropertyName = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(6) > ptcs-dropdown:nth-child(1)"));
				WebElement lastPropertyName = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementPropertyName);
				WebElement property=lastPropertyName.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
				return property;
	}
	public final WebElement propertyNameValue(int i) {
		try {
			WebElement shadowDomHostElementPropertyNameValue = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(31)"));
			WebElement lastPropertyNameValue = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementPropertyNameValue);
			WebElement propertyValue=lastPropertyNameValue.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("+i+") > div:nth-child(1)"));
			return propertyValue;
		} catch (Exception e) {
			return null;
		}
	}
	public final WebElement alertName() throws InterruptedException {
		String cssSelectorForHostAlertName = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(14) > ptcs-textarea:nth-child(1)";
		WebElement shadowDomHostElementAlertName = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(14) > ptcs-textarea:nth-child(1)"));
		WebElement lastAlertName = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertName);
		WebElement alert=lastAlertName.findElement(By.cssSelector("textarea[part='text-value']"));
		return alert;
	}
	public final WebElement alertType() {
		return driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[2]/div[1]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[1]/div[1]/div[1]/div[15]/div[1]/table[1]/tbody[1]/tr[1]/td[1]"));
	}
	public final WebElement alertValue() throws InterruptedException {
		String cssSelectorForHostAlertValue = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(10) > ptcs-textarea:nth-child(1)";
		WebElement shadowDomHostElementAlertValue = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(10) > ptcs-textarea:nth-child(1)"));
		WebElement lastAlertValue = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertValue);
		WebElement alertValue=lastAlertValue.findElement(By.cssSelector("textarea[part='text-value']"));
		return alertValue;
	}
	public final WebElement limit() throws InterruptedException {
		WebElement shadowDomHostElementLimitInclusive = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(12) > ptcs-toggle-button:nth-child(1)"));
		WebElement lastAddLimitInclusive = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementLimitInclusive);
		WebElement limit=lastAddLimitInclusive.findElement(By.cssSelector("div[part='rectangle']"));
		return limit;
	}
	public final WebElement add() {
		return driver.findElement(By.id("root_mashupcontainer-5_ptcsbutton-263"));
	}
	
	public String check() throws InterruptedException {
        Thread.sleep(1000);
        String status=driver.findElement(By.xpath("//div[@id='status-msg-text']")).getText();
        return status;
    }
	}

