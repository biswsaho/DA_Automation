package com.cg.pages.locators.family;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewMeasurementPointLocator {

	WebDriver driver;
	
	// Constructor
	public NewMeasurementPointLocator(WebDriver driver) {
		this.driver = driver;
	}
	
	// Stream drop down
	public WebElement streamDropDown() throws InterruptedException {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(4) > div:nth-child(1) > div:nth-child(1) > div:nth-child(4) > ptcs-dropdown:nth-child(3)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		Thread.sleep(1000);
		return last.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
	}
	
	// Stream drop down
	public WebElement streamDropDownValue(int i) throws InterruptedException {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(38)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		Thread.sleep(1000);
		WebElement stream = last.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("+i+") > div:nth-child(1)"));
		return stream;
	}
	
	// Stream drop down list
	public List<WebElement> streamDropDownValueList(){
		List<WebElement> streamOptions = new ArrayList<WebElement>();
		  int i = 1;
		  System.out.println("streamDropDownValueList");
		  while(true) { 
			  try { 
			  WebElement streamValue = streamDropDownValue(i);
			  if(streamValue==null)
				  break;
			  streamOptions.add(streamValue); 
			  i++;
			  }
		  catch (Exception e) { 
			  break; 
			  } 
		  }
		return streamOptions;
	}
	
	// Family Drop down start
	// Drop down
	public WebElement familyDropDown() throws InterruptedException {
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(4) > div:nth-child(1) > div:nth-child(1) > div:nth-child(6) > ptcs-dropdown:nth-child(3)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		Thread.sleep(1000);
		return last.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
	}
	
	// Drop down value
	public WebElement familyDropDownValue(int i) throws InterruptedException {
		String cssSelectorForHost1 = "body > ptcs-list:nth-child(39)";
		Thread.sleep(1000);
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(39)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		Thread.sleep(1000);
		return last.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("+i+") > div:nth-child(1)"));
		}
	//This Element is inside single shadow DOM.
	
	// Family drop down list
	public List<WebElement> familyDropDownValueList(){
		List<WebElement> familyOptions = new ArrayList<WebElement>();
		  int i = 1;
		  
		  while(true) { 
			  try { 
			  WebElement familyValue = familyDropDownValue(i);
			  if(familyValue==null)
				  break;
			  familyOptions.add(familyValue); 
			  i++;
			  }
		  catch (Exception e) { 
			  break; 
			  } 
		  }
		return familyOptions;
	}
	
	// Measurement point name
	public void measurementPointName(String value) throws InterruptedException {
		List<WebElement> tableOptions = getmeasurementPointTableList();
		
		boolean flag = true;
		
		for(int i = 0; i < tableOptions.size(); i++) {
			if(tableOptions.get(i).getText().equals(value)) {
				flag = false;
			}
		}
		
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(4) > div:nth-child(1) > div:nth-child(1) > div:nth-child(7) > ptcs-textfield:nth-child(3)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		last.findElement(By.cssSelector("input[type='text']")).sendKeys(value);
		Thread.sleep(1000);
//		if(flag) {
////			System.out.println("MP is not present with this name");
//		}else {
//			System.out.println("MP name is already present");
//		}
		}
	
	// Single Table Value 
	public WebElement measurementPointTable(int i) {
		try {
			return driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr["+ i +"]/td[1]"));
		
		} catch (Exception e) {
			return null;
		}
	}
	
	// Table options
	public List<WebElement> getmeasurementPointTableList(){
		  List<WebElement> tableOptions = new ArrayList<WebElement>();
		  int i = 2;
		  
		  while(true) { 
			  try { 
			  WebElement tableNo = measurementPointTable(i);
			  if(tableNo==null)
				  break;
			  tableOptions.add(tableNo); 
			  i++;
			  }
		  catch (Exception e) { 
			  break; 
			  } 
		  }
		  return tableOptions;
	}
	public WebElement addButton() {
		return driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(4) > div:nth-child(1) > div:nth-child(1) > div:nth-child(8) > ptcs-button:nth-child(3)"));
	}
	
	// Success text
	public WebElement successText() {
		return driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[6]/div[3]/div[1]/div[1]"));
	}
}
