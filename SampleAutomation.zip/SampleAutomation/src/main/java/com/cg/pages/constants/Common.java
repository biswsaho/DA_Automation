package com.cg.pages.constants;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Common {
	WebDriver driver;

	public Common(WebDriver driver) {
		this.driver = driver;
	}

	public final WebElement getSiteDropDown() throws InterruptedException {
		WebElement shadowDomHostElementSite = driver.findElement(By.cssSelector(
				"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(3)"));
		WebElement lastSite = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot",
				shadowDomHostElementSite);
		return lastSite.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
	}

	public final WebElement getSiteDropDownValue(int i) throws InterruptedException {
		try {
			WebElement shadowDomHostElementSiteValue = driver
					.findElement(By.cssSelector("body > ptcs-list:nth-child(25)"));
			WebElement lastSiteValue = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
			WebElement site = lastSiteValue.findElement(By.cssSelector(
					"div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("
							+ i + ") > div:nth-child(1)"));
			return site;
		} catch (Exception e) {
			return null;
		}

	}

	public List<WebElement> getSiteDropDownList() {
		List<WebElement> SiteOptions = new ArrayList<WebElement>();
		int i = 1;

		while (true) {
			try {
				WebElement siteNo = getSiteDropDownValue(i);
				if (siteNo == null)
					break;
				SiteOptions.add(siteNo);
				i++;

			} catch (Exception e) {
				break;
			}
		}
		return SiteOptions;
	}

	// global check list
	public WebElement checkList(List<WebElement> options, String value) throws InterruptedException {

		for (int j = 0; j < options.size(); j++) {
			if (options.get(j).getText().equals(value)) {
				return options.get(j);
			}
		}

		return null;
	}
	// end

	public final WebElement getBuildingDropDown() throws InterruptedException {
		// Building DropDown
		String cssSelectorForHostBuilding = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > ptcs-dropdown:nth-child(3)";
		Thread.sleep(1000);
		WebElement shadowDomHostElementBuilding = driver.findElement(By.cssSelector(
				"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > ptcs-dropdown:nth-child(3)"));
		WebElement lastBuilding = (WebElement) ((JavascriptExecutor) driver)
				.executeScript("return arguments[0].shadowRoot", shadowDomHostElementBuilding);
		return lastBuilding.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
	}

	public final WebElement getBuildingDropDownValue(int i) throws InterruptedException {
		try {

			WebElement shadowDomHostElementBuildingValue = driver
					.findElement(By.cssSelector("body > ptcs-list:nth-child(26)"));
			WebElement lastBuildingValue = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElementBuildingValue);
			WebElement building = lastBuildingValue.findElement(By.cssSelector(
					"div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("
							+ i + ") > div:nth-child(1)"));
			return building;
		} catch (Exception e) {
			return null;
		}
	}

	public List<WebElement> getBuildingDropDownList() {
		List<WebElement> buildingOptions = new ArrayList<WebElement>();
		int i = 1;

		while (true) {
			try {
				WebElement buildingNo = getBuildingDropDownValue(i);
				if (buildingNo == null)
					break;
				buildingOptions.add(buildingNo);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		return buildingOptions;
	}

	// Alert Configuration Tab
	public final WebElement selectTab(int i) {
		try {
			// tab options
			WebElement shadowDomHostElementAlertConfiguration1 = driver.findElement(By.cssSelector(
					"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1)"));
			WebElement lastAlertConfiguration1 = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertConfiguration1);
			WebElement shadowDomHostElementAlertConfiguration2 = lastAlertConfiguration1.findElement(By
					.cssSelector(" ptcs-tabs:nth-child(2) > ptcs-tab:nth-child(" + i + ") > ptcs-label:nth-child(1)"));
			WebElement lastAlertConfiguration2 = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertConfiguration2);
			WebElement temp = lastAlertConfiguration2.findElement(By.cssSelector("div[part='label']"));
			return temp;
		} catch (Exception e) {
			return null;
		}
	}

	public List<WebElement> getTab() {
		List<WebElement> tabOptions = new ArrayList<WebElement>();
		int i = 1;

		while (true) {
			try {
				WebElement tabNo = selectTab(i);
				if (tabNo == null)
					break;
				tabOptions.add(tabNo);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		return tabOptions;
	}

	// Add, Edit, Delete tab

	public final WebElement selectSubTab(int i) {
		try {
			WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector(
					"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1)"));
			WebElement last0 = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
			WebElement shadowDomHostElement1 = last0.findElement(By
					.cssSelector(" ptcs-tabs:nth-child(2) > ptcs-tab:nth-child(" + i + ") > ptcs-label:nth-child(1)"));
			WebElement last1 = (WebElement) ((JavascriptExecutor) driver)
					.executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
			WebElement subTab = last1.findElement(By.cssSelector("div[part='label']"));
			return subTab;

		} catch (Exception e) {
			return null;
		}
	}

	public List<WebElement> getSubTab() {
		List<WebElement> tabOptions = new ArrayList<WebElement>();
		int i = 1;

		while (true) {
			try {
				WebElement tabNo = selectSubTab(i);
				if (tabNo == null)
					break;
				tabOptions.add(tabNo);
				i++;
			} catch (Exception e) {
				break;
			}
		}
		return tabOptions;
	}
	
	// New Code for fetching data
	
	public WebElement newGetSiteList(String value) throws InterruptedException {
		Thread.sleep(1000);
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(25)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		List<WebElement> siteList = last.findElements(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1)"));
		System.out.println(siteList.size());
		for(WebElement x: siteList)
		  {
//			System.out.println(x.getText());
//			if(x.getText().equals(value)) {
//				return x;
//			}
		  }
		
		return null;
	}
	
	public void siteDropdown() throws InterruptedException {
		Thread.sleep(2000);
		
		WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(25)"));
		WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
		List<WebElement> options = last.findElements(By.cssSelector("ptcs-v-scroller[part='list-items-container']"));
		
		System.out.println(options.size());
		for(int i=0; i<options.size(); i++) {
			System.out.println(options.get(i).getText());
//			if (options.get(i).getText().equals("SIte01")) {
//				System.out.println("Matched");
//			}else {
//				System.out.println("Not Matched");
//			}
		}
//		for(WebElement x: options)
//		  {
////			System.out.println(x.getText().toString().equals("Site02"));
////			if (x.getText().toString().equals("Site02")) {
////				System.out.println("Clicked");
////			}else {
////				System.out.println("Not clicked");
////			}
//			System.out.println(x.getText());
//		  }
	}
	
	// New functions with improved speed time
	public WebElement getSiteDropDownListNew(String value) {
		int i = 1;

		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElementSiteValue = driver
						.findElement(By.cssSelector("body > ptcs-list:nth-child(25)"));
				WebElement lastSiteValue = (WebElement) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElementSiteValue);
				WebElement site = lastSiteValue.findElement(By.cssSelector(
						"div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("
								+ i + ") > div:nth-child(1)"));
				
				if(site.getText().equals(value)) {
					return site;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	public WebElement getBuildingDropDownListNew(String value) {
		int i = 1;
		
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElementBuildingValue = driver
						.findElement(By.cssSelector("body > ptcs-list:nth-child(26)"));
				WebElement lastBuildingValue = (WebElement) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElementBuildingValue);
				WebElement building = lastBuildingValue.findElement(By.cssSelector(
						"div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("
								+ i + ") > div:nth-child(1)"));
				
				if(building.getText().equals(value)) {
					return building;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	public WebElement getTabNew(String value) {
		int i = 1;
		
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElementAlertConfiguration1 = driver.findElement(By.cssSelector(
						"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1)"));
				WebElement lastAlertConfiguration1 = (WebElement) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertConfiguration1);
				WebElement shadowDomHostElementAlertConfiguration2 = lastAlertConfiguration1.findElement(By
						.cssSelector(" ptcs-tabs:nth-child(2) > ptcs-tab:nth-child(" + i + ") > ptcs-label:nth-child(1)"));
				WebElement lastAlertConfiguration2 = (WebElement) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElementAlertConfiguration2);
				WebElement tab = lastAlertConfiguration2.findElement(By.cssSelector("div[part='label']"));
				
				if(tab.getText().equals(value)) {
					return tab;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	public final WebElement selectSubTabNew(String value) {
		int i = 1;
		
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElement0 = driver.findElement(By.cssSelector(
						"body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1)"));
				WebElement last0 = (WebElement) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElement0);
				WebElement shadowDomHostElement1 = last0.findElement(By
						.cssSelector(" ptcs-tabs:nth-child(2) > ptcs-tab:nth-child(" + i + ") > ptcs-label:nth-child(1)"));
				WebElement last1 = (WebElement) ((JavascriptExecutor) driver)
						.executeScript("return arguments[0].shadowRoot", shadowDomHostElement1);
				WebElement subTab = last1.findElement(By.cssSelector("div[part='label']"));
				
				if(subTab.getText().equals(value)) {
					return subTab;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	// Family Button 
	public WebElement familyRadioButton(String value) {
		 WebElement Family = driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[2]/div[1]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[1]/div[1]/div[1]/div[1]/div[3]/table[1]/tbody[1]/tr[1]/td[1]"));
		 WebElement MeasurementPoint = driver.findElement(By.xpath("//body[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[2]/div[1]/div[1]/div[1]/div[3]/ptcs-tab-set[1]/ptcs-mb-container[1]/div[1]/div[1]/div[1]/div[3]/table[1]/tbody[1]/tr[1]/td[2]"));
	     
		 if(value.equals("Family")) {
			 return Family;
		 }
	     
		 return MeasurementPoint;
	}
	
	// Family drop down
	public final WebElement familyDropDown() throws InterruptedException {
			String cssSelectorForHostFamilyDropDown = "body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(1)";
			WebElement shadowDomHostElementFamilyDropDown = driver.findElement(By.cssSelector("body > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-tab-set:nth-child(1) > ptcs-mb-container:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > ptcs-dropdown:nth-child(1)"));
			WebElement lastFamilyDropDown = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDown);
			WebElement family=lastFamilyDropDown.findElement(By.cssSelector("ptcs-hbar[part='select-box']"));
			return family;
	}
	
	// Family name
	public final WebElement familyDropDownListNew(String value) throws InterruptedException {
		int i = 1;
		
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElementFamilyDropDownValue = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(30)"));
				WebElement lastFamilyDropDownValue = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementFamilyDropDownValue);
				WebElement familyValue = lastFamilyDropDownValue.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("+i+") > div:nth-child(1)"));
				
				if(familyValue.getText().equals(value)) {
					return familyValue;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	// Property name
	public final WebElement propertyNameDropDownListNew(String value) throws InterruptedException {
		int i = 1;
		
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElementPropertyNameValue = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(31)"));
				WebElement lastPropertyNameValue = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElementPropertyNameValue);
				WebElement propertyValue = lastPropertyNameValue.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child("+i+") > div:nth-child(1)"));
				
				if(propertyValue.getText().equals(value)) {
					return propertyValue;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	public String statusMessage() {
		return driver.findElement(By.xpath("//div[@class='tw-status-msg-box']//div[@id='status-msg-text']")).getText();
	}
	
	// Delete Family Test Case
	
	// Family Name Drop Down	
	public final WebElement deleteFamilyDropDownListNew(String value) throws InterruptedException {
		int i = 1;
		System.out.println("In family function");
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(36)"));
				WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
				Thread.sleep(100);
				WebElement familyValue = last.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child(" + i + ") > div:nth-child(1)"));
				
				if(familyValue.getText().equals(value)) {
					System.out.println(familyValue.getText());
					return familyValue;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	// Property Name Drop Down	
	public final WebElement deletePropertyNameDropDownListNew(String value) throws InterruptedException {
		int i = 1;
		
		while (true) {
			try {
				Thread.sleep(100);
				WebElement shadowDomHostElement = driver.findElement(By.cssSelector("body > ptcs-list:nth-child(37)"));
				WebElement last = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowDomHostElement);
				Thread.sleep(100);
				WebElement propertyNameValue = last.findElement(By.cssSelector("div:nth-child(4) > ptcs-v-scroller:nth-child(3) > div:nth-child(1) > div:nth-child(1) > ptcs-list-item:nth-child(" + i + ") > div:nth-child(1)"));
				
				if(propertyNameValue.getText().equals(value)) {
					return propertyNameValue;
				}
				
				i++;
			} catch (Exception e) {
				return null;
			}
		}
	}
	
	// Delete family table 
	public final WebElement deleteTableElement(String value) {
		List<WebElement> tableList = driver.findElements(By.xpath("//*[@id=\"root_mashupcontainer-5_convergedhxgrid-308-dhxgrid\"]//div[@class=\"objbox\"]//child::table//tr//td[1]"));
		
		for(int i = 1; i < tableList.size(); i++) {
			if(tableList.get(i).getText().equals(value)) {
				return tableList.get(i);
			}
		}
		return null;
	}
}
